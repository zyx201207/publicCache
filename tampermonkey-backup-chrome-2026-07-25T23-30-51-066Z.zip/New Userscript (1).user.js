// ==UserScript==
// @name         New Userscript
// @namespace    http://tampermonkey.net/
// @version      2026-05-18
// @description  try to take over the world!
// @author       You
// @match        https://zyxot.xo.je/benben
// @icon         https://www.google.com/s2/favicons?sz=64&domain=xo.je
// @grant        none
// ==/UserScript==

function modify() {
    const par = document.querySelector("#comment-markdown-input-container > div > div.card-body.tab-content.p-0");
    const elem = document.createElement("div"),editor = document.querySelector("#div-comment_editor");
    elem.style = "height: 5px; background: #A0A0A0; cursor: ns-resize;";
    let dragging = 0,startY = 0,startHeight = 0;
    function onMouseDown(e) {
        dragging = true;
        startY = e.clientY;
        startHeight = editor.offsetHeight;
        e.preventDefault();
        document.addEventListener('mousemove', onMouseMove);
        document.addEventListener('mouseup', onMouseUp);
    }

    function onMouseMove(e) {
        if (!dragging) return;
        const deltaY = e.clientY - startY;
        let newHeight = startHeight + deltaY;
        if (newHeight < 50) newHeight = MIN_HEIGHT;
        if (newHeight > 600) newHeight = MAX_HEIGHT;

        editor.style.height = newHeight + 'px';
    }

    function onMouseUp() {
        if (!dragging) return;
        dragging = false;
        document.removeEventListener('mousemove', onMouseMove);
        document.removeEventListener('mouseup', onMouseUp);
    }

    elem.addEventListener('mousedown', onMouseDown);
    par.append(elem);
};

modify();