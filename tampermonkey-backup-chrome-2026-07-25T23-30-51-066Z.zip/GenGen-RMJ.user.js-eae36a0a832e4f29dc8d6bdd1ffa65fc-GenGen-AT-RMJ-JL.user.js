// ==UserScript==
// @name         GenGen-AT-RMJ-JL
// @namespace    http://tampermonkey.net/
// @version      3.2
// @author       GenGen 队
// @match        https://www.luogu.com.cn/record/list*
// @grant        GM_xmlhttpRequest
// @grant        GM_setValue
// @grant        GM_getValue
// @connect      atcoder.jp
// @connect      kenkoooo.com
// @connect      j.1win.ggff.net
// @run-at       document-end
// @description  GenGen RMJ （ATcoder 记录 + 快速启动 + 题目名增强）
// ==/UserScript==

(async function () {
  'use strict';
  if (document.readyState !== 'complete')
    await new Promise(r => addEventListener('load', r, { once: true }));
  const startTime = Date.now();
  const params = new URLSearchParams(window.location.search);
  const rmj = params.get('rmj');
  const contest = params.get('contest');
  const pid = params.get('pid') || '';

  if (rmj !== '2') return;

  // ========== 配置 ==========
  const FINAL_STATUSES = new Set(['AC', 'WA', 'CE', 'RE', 'TLE', 'MLE', 'OLE', 'IE']);
  const STATUS_MAP = {
    'AC': { full: 'Accepted', cls: 'cf-status-accepted' },
    'WA': { full: 'Wrong Answer', cls: 'cf-status-wrong' },
    'CE': { full: 'Compilation Error', cls: 'cf-status-ce' },
    'RE': { full: 'Runtime Error', cls: 'cf-status-re' },
    'TLE': { full: 'Time Limit Exceeded', cls: 'cf-status-limit' },
    'MLE': { full: 'Memory Limit Exceeded', cls: 'cf-status-limit' },
    'OLE': { full: 'Output Limit Exceeded', cls: 'cf-status-limit' },
    'IE': { full: 'Internal Error', cls: 'cf-status-ce' }
  };

  // ========== 注入样式 ==========
  const style = document.createElement('style');
  style.textContent = `
    .cf-card { display: flex; align-items: center; font-size: 16px; padding: 10px 0; border-bottom: 1px solid #eee; }
    .cf-avatar img { width: 36px; height: 36px; border-radius: 50%; margin-right: 12px; }
    .cf-nameblock { display: flex; flex-direction: column; width: 180px; margin-right: 12px; }
    .cf-name { font-weight: bold; color: #333; font-size: 16px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .cf-time { font-size: 14px; color: #888; line-height: 1.2; margin-top: 2px; white-space: nowrap; }
    .cf-status { flex: 0 0 auto; margin-right: 12px; text-align: left; width: 250px; }
    .cf-status span {
      border-radius: 2px; padding: 4px 8px; font-size: 14px; font-weight: 600; white-space: nowrap;
      display: fixed; max-width: 100%; overflow: hidden; text-overflow: ellipsis;
    }
    .cf-status-accepted { background: rgb(82, 196, 26); color: #fff; }
    .cf-status-wrong { background: rgb(231, 76, 60); color: #fff; }
    .cf-status-re { background: rgb(157, 61, 207); color: #fff; }
    .cf-status-ce { background: rgb(250, 219, 20); color: #fff; }
    .cf-status-limit { background: rgb(5, 34, 66); color: #fff; }
    .cf-status-running { background: #888; color: #fff; }
    .cf-status-other { background: rgb(243, 156, 17); color: #fff; }
    .cf-problem { flex: 1; color: rgb(52, 152, 219); font-size: 16px; text-align: left; min-width: 100px; margin-left: 60px; }
    .cf-error { padding: 10px; color: #e74c3c; font-weight: bold; }
    .cf-loading { padding: 10px; color: ＃708090; font-weight: bold; }
  `;
  document.head.appendChild(style);

  // ========== 工具函数 ==========
  function getLuoguUserInfo() {
    const nameEl = document.querySelector('#app .user-nav > a > span') ||
                   document.querySelector('div.header span a span') ||
                   document.querySelector('.username');
    const avatarEl = document.querySelector('#app .user-nav a img');
    return {
      name: (nameEl?.textContent || 'User').trim(),
      color: nameEl?.style?.color || '#333',
      avatar: (avatarEl?.src || 'https://cdn.luogu.com.cn/upload/usericon/default.png').trim()
    };
  }

  function sanitizeAtcoderUrl(url, contestId) {
    if (url.startsWith('https://atcoder.jp/')) return url;
    const luoguMatch = url.match(/luogu\.com\.cn\/contests\/([^\/]+)\/submissions\/(\d+)/);
    if (luoguMatch) return `https://atcoder.jp/contests/${luoguMatch[1]}/submissions/${luoguMatch[2]}`;
    try {
      return new URL(url, `https://atcoder.jp/contests/${contestId}/`).href;
    } catch {
      return `https://atcoder.jp/contests/${contestId}/submissions/${url.split('/').pop()}`;
    }
  }

  function createCfCard(taskDisplay, isFinal, rawStatus, timeText, atcoderUrl, luoguUrl, id = '') {
    const card = document.createElement('div');
    card.className = 'cf-card';
    if (id) card.dataset.id = id;

    const { name, color, avatar } = getLuoguUserInfo();
    const avatarDiv = document.createElement('div');
    avatarDiv.className = 'cf-avatar';
    const img = document.createElement('img');
    img.src = avatar;
    img.onerror = () => img.src = 'https://cdn.luogu.com.cn/upload/usericon/1.png';
    avatarDiv.appendChild(img);

    const nameBlock = document.createElement('div');
    nameBlock.className = 'cf-nameblock';
    const nameDiv = document.createElement('div');
    nameDiv.className = 'cf-name';
    nameDiv.style.color = color;
    nameDiv.textContent = name;
    const timeDiv = document.createElement('div');
    timeDiv.className = 'cf-time';
    timeDiv.textContent = timeText;
    nameBlock.append(nameDiv, timeDiv);

    const statusDiv = document.createElement('div');
    statusDiv.className = 'cf-status';
    const statusLink = document.createElement('a');
    statusLink.href = atcoderUrl;
    statusLink.target = '_blank';
    statusLink.rel = 'noopener noreferrer';
    const span = document.createElement('span');

    if (isFinal) {
      const { full, cls } = STATUS_MAP[rawStatus] || { full: rawStatus, cls: 'cf-status-other' };
      span.className = cls;
      span.textContent = full;
    } else {
      span.className = 'cf-status-running';
      span.textContent = rawStatus;
    }
    statusLink.appendChild(span);
    statusDiv.appendChild(statusLink);

    const problemDiv = document.createElement('div');
    problemDiv.className = 'cf-problem';
    const probLink = document.createElement('a');
    probLink.href = luoguUrl;
    probLink.textContent = taskDisplay;
    probLink.target = '_blank';
    probLink.rel = 'noopener noreferrer';
    problemDiv.appendChild(probLink);
    card.append(avatarDiv, nameBlock, statusDiv, problemDiv);
    return card;
  }

  function getCache() {
    try {
      return JSON.parse(GM_getValue('at-submissions-cache', '[]')).map(item => ({
        ...item,
        atcoderSubmissionUrl: sanitizeAtcoderUrl(item.atcoderSubmissionUrl, item.taskKey?.split('_')[0] || '')
      }));
    } catch {
      console.warn('[Gen-AT-RMJ] 缓存解析失败，重置');
      return [];
    }
  }

  function saveCache(cache) {
    const clean = cache.map(item => ({
      ...item,
      atcoderSubmissionUrl: sanitizeAtcoderUrl(item.atcoderSubmissionUrl, item.taskKey?.split('_')[0] || '')
    }));
    GM_setValue('at-submissions-cache', JSON.stringify(clean));
  }

  async function fetchLatestSubmission(contest) {
    return new Promise((resolve, reject) => {
      const timeout = setTimeout(() => reject(new Error('Timeout')), 8000);
      GM_xmlhttpRequest({
        method: 'GET',
        url: `https://atcoder.jp/contests/${contest}/submissions/me`,
        onload: res => {
          clearTimeout(timeout);
          if (res.status !== 200) return reject(new Error(`HTTP ${res.status}`));
          try {
            const doc = new DOMParser().parseFromString(res.responseText, 'text/html');
            const row = doc.querySelector('table.table tbody tr');
            if (!row) return resolve(null);

            const cells = Array.from(row.querySelectorAll('td'));
            if (cells.length < 7) throw new Error('Invalid columns');

            const timeEl = cells[0]?.querySelector('time');
            const timeText = timeEl?.innerText.trim() || 'Unknown Time';

            const taskLink = cells[1]?.querySelector('a');
            const taskHref = taskLink?.href || '';
            const taskName = taskLink?.innerText?.trim() || 'Unknown Task';
            const taskKey = taskHref.match(/\/tasks\/([^\/\s]+)/)?.[1] || 'Unknown';
            const taskDisplay = `${taskKey} - ${taskName}`;
            const luoguProblemUrl = `https://www.luogu.com.cn/problem/AT_${taskKey}`;
            let rawStatus = 'Unknown';
            for (const cell of cells) {
              const label = cell.querySelector('.label');
              if (label) {
                rawStatus = label.innerText.trim();
                break;
              }
            }

            const detailAnchor = cells[cells.length - 1]?.querySelector('a.submission-details-link');
            if (!detailAnchor?.href) throw new Error('No detail link');

            const submissionId = detailAnchor.href.split('/').pop();
            const atcoderSubmissionUrl = `https://atcoder.jp/contests/${contest}/submissions/${submissionId}`;
            const isFinal = FINAL_STATUSES.has(rawStatus);

            resolve({ submissionId, taskKey, taskName, taskDisplay, rawStatus, atcoderSubmissionUrl, luoguProblemUrl, timeText, isFinal });
          } catch (err) {
            reject(err);
          }
        },
        onerror: () => {
          clearTimeout(timeout);
          reject(new Error('Network error'));
        }
      });
    });
  }

  async function fetchProblemsMap() {
    try {
      const data = await new Promise((resolve, reject) => {
        GM_xmlhttpRequest({
          method: 'GET',
          url: 'https://kenkoooo.com/atcoder/resources/problems.json',
          onload: res => {
            if (res.status === 200) {
              try {
                resolve(JSON.parse(res.responseText));
              } catch (e) {
                reject(e);
              }
            } else {
              reject(new Error(`problems.json: ${res.status}`));
            }
          },
          onerror: () => reject(new Error('Network error fetching problems.json'))
        });
      });

      const map = new Map();
      for (const p of data) {
        if (p.id) {
          map.set(p.id, {
            index: p.problem_index || '',
            name: p.name || ''
          });
        }
      }
      return map;
    } catch (err) {
      console.warn('[Gen-AT-RMJ] Failed to fetch problems.json:', err.message || err);
      return new Map();
    }
  }

  async function fetchKenkooooSubmissions(problemsMap) {
    try {
      const response = await new Promise((resolve, reject) => {
        GM_xmlhttpRequest({
          method: 'GET',
          url: 'https://atcoder.jp/',
          onload: res => {
            if (res.status === 200) resolve(res.responseText);
            else reject(new Error(`Failed to fetch AtCoder homepage: ${res.status}`));
          },
          onerror: () => reject(new Error('Network error fetching AtCoder homepage'))
        });
      });

      const parser = new DOMParser();
      const doc = parser.parseFromString(response, 'text/html');
      const userElement = doc.querySelector("#navbar-collapse > ul.nav.navbar-nav.navbar-right > li:nth-child(2) > a");
      if (!userElement) throw new Error("Cannot find AtCoder username");

      const userId = userElement.textContent.trim();
      if (!userId) throw new Error("Empty AtCoder username");

      const submissionsResponse = await new Promise((resolve, reject) => {
        GM_xmlhttpRequest({
          method: 'GET',
          url: `https://kenkoooo.com/atcoder/atcoder-api/v3/user/submissions?user=${encodeURIComponent(userId)}&from_second=0`,
          onload: res => {
            if (res.status === 200) {
              try {
                resolve(JSON.parse(res.responseText));
              } catch (e) {
                reject(e);
              }
            } else {
              reject(new Error(`Kenkoooo API error: ${res.status}`));
            }
          },
          onerror: () => reject(new Error('Network error fetching Kenkoooo data'))
        });
      });

      if (!Array.isArray(submissionsResponse)) throw new Error("Invalid Kenkoooo response");

      return submissionsResponse.map(sub => {
        const problemId = sub.problem_id;
        let taskDisplay;
        const probInfo = problemsMap.get(problemId);
        if (probInfo && probInfo.name && probInfo.index) {
          taskDisplay = `${problemId} - ${probInfo.index} - ${probInfo.name}`;
        } else {
          const parts = problemId.split('_');
          const contest = parts[0] || '';
          const idx = parts[1] ? parts[1].toUpperCase() : '';
          const fallbackName = idx ? `${contest.toUpperCase()} ${idx}` : problemId;
          taskDisplay = `${problemId} - ${fallbackName}`;
        }

        return {
          id: String(sub.id),
          taskKey: problemId,
          taskName: taskDisplay,
          taskDisplay: taskDisplay,
          status: sub.result,
          atcoderSubmissionUrl: `https://atcoder.jp/contests/${sub.contest_id}/submissions/${sub.id}`,
          luoguProblemUrl: `https://www.luogu.com.cn/problem/AT_${problemId}`,
          timestamp: sub.epoch_second * 1000,
          isFinal: FINAL_STATUSES.has(sub.result)
        };
      });
    } catch (err) {
      console.warn('[Gen-AT-RMJ] Failed to fetch Kenkoooo submissions:', err.message || err);
      return [];
    }
  }

  function updateRecordCount(count) {
    const countSpan = document.querySelector('#app > div.main-container > main > div > section > div > div > span > span');
    if (countSpan) {
      countSpan.textContent = count.toString();
    }
  }

  function renderCache(cache, mainDiv) {
    let filtered = cache;
    if (searchFilter) {
      const normQuery = searchFilter.replace(/^AT_/i, '').toLowerCase();
      filtered = cache.filter(s => s.taskDisplay.toLowerCase().includes(normQuery));
    }

    displayedIds.clear();

    mainDiv.innerHTML = '';
    updateRecordCount(filtered.length);

    if (filtered.length === 0) {
      const elapsed = Date.now() - startTime; 
      const msg = document.createElement('div');
      if (elapsed < 5000) {
        msg.className = 'cf-loading';
        msg.textContent = '加载中...';
      } else {
        msg.className = 'cf-error';
        msg.textContent = '没有提交记录';
      }
      mainDiv.appendChild(msg);
    } else {
      filtered.forEach(sub => {
        const timeText = new Date(sub.timestamp).toLocaleString('zh-CN');
        const card = createCfCard(sub.taskDisplay, sub.isFinal, sub.status, timeText, sub.atcoderSubmissionUrl, sub.luoguProblemUrl, sub.id);
        displayedIds.add(sub.id);
        mainDiv.appendChild(card);
      });
    }
  }

  function waitForElement(selector, timeout = 10000) {
    return new Promise((resolve, reject) => {
      const el = document.querySelector(selector);
      if (el) return resolve(el);
      const observer = new MutationObserver(() => {
        const found = document.querySelector(selector);
        if (found) {
          observer.disconnect();
          resolve(found);
        }
      });
      observer.observe(document.body, { childList: true, subtree: true });
      setTimeout(() => {
        observer.disconnect();
        reject(new Error(`Timeout: ${selector}`));
      }, timeout);
    });
  }

  // ========== 主流程 ==========
  let displayedIds = new Set();
  let searchFilter = pid;

  async function bindSearch(mainDiv) {
    try {
      const input = await waitForElement('#app main section div section:nth-child(1) div div:nth-child(1) input', 8000);
      input.value = searchFilter;
      const originalOnInput = input.oninput;
      input.oninput = (e) => {
        searchFilter = e.target.value.trim();
        const url = new URL(window.location);
        if (searchFilter) url.searchParams.set('pid', searchFilter);
        else url.searchParams.delete('pid');
        history.replaceState(null, '', url);
        renderCache(getCache(), mainDiv);
        originalOnInput?.call(input, e);
      };
    } catch (e) {
      console.warn('[Gen-AT-RMJ] 搜索框未找到');
    }
  }

  async function main() {
    let mainDiv;
    try {
      mainDiv = await waitForElement('main > div > div', 10000);
    } catch {
      const appMain = document.querySelector('#app main') || document.body;
      mainDiv = document.createElement('div');
      appMain.appendChild(mainDiv);
    }

    // ✅ 第一步：立即用本地缓存渲染（快速响应）
    let cache = getCache();
    renderCache(cache, mainDiv);
    await bindSearch(mainDiv);

    // ✅ 第二步：后台异步加载 Kenkoooo 全量数据（不阻塞 UI）
    (async () => {
      try {
        const [problemsMap, kenkooooSubs] = await Promise.all([
          fetchProblemsMap(),
          fetchKenkooooSubmissions(new Map()) // 先传空 map，等下替换
        ]);

        // 重新用正确的 problemsMap 生成 taskDisplay
        const enhancedSubs = kenkooooSubs.map(sub => {
          const problemId = sub.taskKey;
          let taskDisplay;
          const probInfo = problemsMap.get(problemId);
          if (probInfo && probInfo.name && probInfo.index) {
            taskDisplay = `${problemId} - ${probInfo.index} - ${probInfo.name}`;
          } else {
            const parts = problemId.split('_');
            const contest = parts[0] || '';
            const idx = parts[1] ? parts[1].toUpperCase() : '';
            const fallbackName = idx ? `${contest.toUpperCase()} ${idx}` : problemId;
            taskDisplay = `${problemId} - ${fallbackName}`;
          }
          return { ...sub, taskDisplay, taskName: taskDisplay };
        });

        // 合并：优先保留 Kenkoooo 的（更全），按 id 去重
        const mergedMap = new Map();
        for (const sub of [...enhancedSubs, ...cache]) {
          if (!mergedMap.has(sub.id)) {
            mergedMap.set(sub.id, sub);
          }
        }

        cache = Array.from(mergedMap.values()).sort((a, b) => Number(b.id) - Number(a.id));
        saveCache(cache);

        // ✅ 第三步：更新 UI（静默刷新）
        renderCache(cache, mainDiv);
      } catch (err) {
        console.warn('[Gen-AT-RMJ] Background Kenkoooo load failed:', err);
      }
    })();

    // ========== 实时轮询（如有 contest）==========
    let pollingInterval;
    const finalized = new Set();

    if (contest) {
      pollingInterval = setInterval(async () => {
        try {
          const res = await fetchLatestSubmission(contest);
          if (!res) return;

          const { submissionId, isFinal } = res;
          if (isFinal && finalized.has(submissionId)) return;

          const existingIndex = cache.findIndex(s => s.id === submissionId);

          const newEntry = {
            id: submissionId,
            taskKey: res.taskKey,
            taskName: res.taskName,
            taskDisplay: res.taskDisplay,
            status: res.rawStatus,
            atcoderSubmissionUrl: res.atcoderSubmissionUrl,
            luoguProblemUrl: res.luoguProblemUrl,
            timestamp: existingIndex >= 0 ? cache[existingIndex].timestamp : Date.now(),
            isFinal: isFinal
          };

          if (existingIndex >= 0) {
            cache[existingIndex] = newEntry;
          } else {
            cache.unshift(newEntry);
          }

          saveCache(cache);
          renderCache(cache, mainDiv);

          if (isFinal) finalized.add(submissionId);
        } catch (err) {
          console.log('[Gen-AT-RMJ] 轮询失败:', err.message || err);
        }
      }, 1000);

      window.addEventListener('beforeunload', () => {
        if (pollingInterval) clearInterval(pollingInterval);
      });
    }
  }

  main().catch(console.error);
})();