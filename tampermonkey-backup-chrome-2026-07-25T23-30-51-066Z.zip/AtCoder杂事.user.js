// ==UserScript==
// @name         AtCoder杂事
// @namespace    http://tampermonkey.net/
// @version      1.0.1
// @author       zyx2012
// @match        *://atcoder.jp/*
// @grant        none
// ==/UserScript==

function main(){
    document.querySelectorAll("#main-container > div.row > div:nth-child(2) > span.h2 > a").forEach((elem) => {
        elem.setAttribute("targe","_blank");
        elem.setAttribute("rel","noopener");
    });
}
setTimeout(main,0);
setTimeout(main,200);
setTimeout(main,400);
setTimeout(main,600);
setTimeout(main,800);
setTimeout(main,1000);
