// ==UserScript==
// @name         New Userscript
// @namespace    http://tampermonkey.net/
// @version      2026-04-22
// @description  try to take over the world!
// @author       You
// @match        *://www.luogu.com.cn/*
// @icon         data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==
// @grant        none
// ==/UserScript==

function main(){
document.querySelectorAll("title").forEach((elem) => {elem.remove();});
}
	setTimeout(main,0);
	setTimeout(main,200);
	setTimeout(main,400);
	setTimeout(main,600);
	setTimeout(main,800);
	setTimeout(main,1000);
