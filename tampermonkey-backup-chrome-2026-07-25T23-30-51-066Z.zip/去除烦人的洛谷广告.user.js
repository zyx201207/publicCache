// ==UserScript==
// @name         去除烦人的洛谷广告
// @namespace    http://tampermonkey.net/
// @version      1.0.1
// @description  去广告
// @author       zyx2012
// @match        *://www.luogu.com.cn/*
// @grant        none
// ==/UserScript==

setTimeout(() => {document.querySelectorAll("[data-v-fdcd5a58][data-v-754e1ea4-s]").forEach((elem) => {elem.remove();});},200);
setTimeout(() => {document.querySelectorAll("[data-v-fdcd5a58][data-v-754e1ea4-s]").forEach((elem) => {elem.remove();});},600);
setTimeout(() => {document.querySelectorAll("[data-v-fdcd5a58][data-v-754e1ea4-s]").forEach((elem) => {elem.remove();});},400);
setTimeout(() => {document.querySelectorAll("[data-v-fdcd5a58][data-v-754e1ea4-s]").forEach((elem) => {elem.remove();});},800);
setTimeout(() => {document.querySelectorAll("[data-v-fdcd5a58][data-v-754e1ea4-s]").forEach((elem) => {elem.remove();});},1000);
