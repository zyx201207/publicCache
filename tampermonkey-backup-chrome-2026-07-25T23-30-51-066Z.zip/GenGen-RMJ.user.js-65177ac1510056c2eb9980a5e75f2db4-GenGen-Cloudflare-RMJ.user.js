// ==UserScript==
// @name        GenGen-Cloudflare-RMJ
// @namespace   http://tampermonkey.net/
// @version     3.2.3
// @match       https://www.luogu.com.cn/problem/AT_*
// @match       https://www.luogu.com.cn/problem/CF*
// @match       https://codeforces.com/problemset/status?my=on
// @match       https://atcoder.jp/contests/*/submit?RMJ=1
// @include     https://codeforces.com/problemset/submit/*
// @grant       GM_setValue
// @grant       GM_getValue
// @grant       GM_addStyle
// @grant       unsafeWindow
// @require     https://html2canvas.hertzen.com/dist/html2canvas.min.js
// @connect     atcoder.jp
// @connect     luogu.com.cn
// @connect     codeforces.com
// @run-at      document-start
// @description GenGen RMJ （Cloudflare 盾 提交）
// @license MIT
// ==/UserScript==

(() => {
    'use strict';
    if(document.referrer.includes('RMJ=1') && window.location.href=="https://codeforces.com/problemset/status?my=on"){
        window.location.replace('https://www.luogu.com.cn/record/list?rmj=1');
    }
    // === 1. 立即注入全局样式（document-start 安全）===
    GM_addStyle(`
        #rmj-overlay {
            position: fixed !important; inset: 0 !important;
            background: rgba(255, 255, 255, 0.95) !important;
            z-index: 999998 !important; display: flex !important;
            flex-direction: column !important; justify-content: center !important;
            align-items: center !important; pointer-events: none !important;
        }
        #rmj-screenshot {
            position: absolute !important; inset: -3px !important;
            width: calc(100% + 6px) !important; height: calc(100% + 6px) !important;
            object-fit: fill !important; filter: blur(0px) !important;
            transition: filter 0.4s ease !important;
            clip-path: inset(3px) !important;
        }
        #rmj-screenshot.blurred {
            filter: blur(5px) !important;
        }
        #rmj-overlay::before {
            content: "" !important; position: absolute !important; inset: 0 !important;
            background: rgba(0, 0, 0, 0.4) !important; z-index: 999999 !important;
            pointer-events: none !important;
        }
        #rmj-overlay-content {
            text-align: center !important; max-width: 100% !important;
            z-index: 1000000 !important; position: relative !important;
            pointer-events: auto !important;
        }
        #rmj-message {
            color: white !important; font-size: 20px !important;
            margin-bottom: 120px !important; z-index: 1000001 !important;
            pointer-events: none !important;
        }
        body.rmj-loading {
            overflow: hidden !important; height: 100vh !important;
        }
    `);

    const href = location.href;
    const storeData = (key, value) => GM_setValue(`gen-at-${key}`, value);
    const getData = (key) => GM_getValue(`gen-at-${key}`, '');
    const clearData = () => {
        ['code', 'contest', 'task', 'back', 'screenshot', 'cf_contest', 'cf_index', 'platform'].forEach(k =>
            GM_setValue(`gen-at-${k}`, '')
        );
    };

    // === 2. 安全创建遮罩（即使 body 未就绪）===
    const createOverlay = () => {
        document.documentElement.style.overflow = 'hidden';
        if (document.getElementById('rmj-overlay')) return;

        const overlay = document.createElement('div');
        overlay.id = 'rmj-overlay';
        overlay.innerHTML = `
            <img id="rmj-screenshot" alt="Screenshot">
            <div id="rmj-overlay-content">
                <div id="rmj-message">请完成验证</div>
            </div>
        `;

        if (document.body) {
            document.body.appendChild(overlay);
        } else {
            const observer = new MutationObserver(() => {
                if (document.body) {
                    document.body.appendChild(overlay);
                    observer.disconnect();
                }
            });
            observer.observe(document.documentElement, { childList: true });
        }
    };

    // === 3. 等待 body 可用后再启动主逻辑 ===
    const waitForBody = (callback) => {
        if (document.body) {
            callback();
        } else {
            const observer = new MutationObserver(() => {
                if (document.body) {
                    observer.disconnect();
                    callback();
                }
            });
            observer.observe(document.documentElement, { childList: true });
        }
    };

    // ========== 主入口 ==========
    waitForBody(() => {
        const isLuogu = href.includes('luogu.com.cn');
        const isAtCoderSubmit = href.includes('atcoder.jp') && href.includes('RMJ=1');
        const isCodeforcesSubmit = href.includes('codeforces.com') && new URL(href).searchParams.get('RMJ') === '1';

        if (isLuogu) {
            if (/\/problem\/AT_/.test(href)) {
                initLuoguAtcoder();
            } else if (/\/problem\/CF\d+[A-Z]\d*/.test(href)) {
                initLuoguCodeforces();
            }
        } else if (isAtCoderSubmit) {
            initAtCoderSubmit();
        } else if (isCodeforcesSubmit) {
            initCodeforcesSubmit();
        }
    });
    async function extractCode() {
      const c = document.querySelector('.cm-content');
      if (!c) return '';

      c.focus();
      await new Promise(r => requestAnimationFrame(() => requestAnimationFrame(r)));

      for (let i = 0; i < 3; i++) {
        c.dispatchEvent(new KeyboardEvent('keydown', { key: 'a', code: 'KeyA', ctrlKey: true, bubbles: true }));
        await new Promise(r => setTimeout(r, 50));

        const d = { data: {}, setData(k, v) { this.data[k] = v; }, clearData() {} };
        const e = new Event('copy', { bubbles: true });
        Object.defineProperty(e, 'clipboardData', { value: d });
        c.dispatchEvent(e);

        const code = d.data['text/plain'] || '';
        if (code.trim()) {
          c.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true }));
          return code;
        }
        await new Promise(r => setTimeout(r, 100 * (i + 1)));
      }

      c.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true }));
      return '';
    }
    // ========== 洛谷：AtCoder 题目 ==========
    async function initLuoguAtcoder() {
        storeData('platform', 'atcoder');
        storeData('back', location.href);

        let btn = null;
        while (!btn) {
            btn = document.querySelector("#app > div.main-container.lside-nav > div > main > div > div > div.main > div > div.body > button");
            await new Promise(r => setTimeout(r, 100));
        }
        const newBtn = btn.cloneNode(true);
        btn.replaceWith(newBtn);

        newBtn.addEventListener('click', async (e) => {
            e.preventDefault(); e.stopImmediatePropagation();
            try {

                let code = await extractCode();

                if (!code?.trim()) throw new Error('代码为空');

                let contestId = '', taskScreenName = '';
                for (const link of document.querySelectorAll('a[href*="atcoder.jp/contests/"]')) {
                    const m = link.href.match(/atcoder\.jp\/contests\/([^\/]+)\/tasks\/([^\/?#]+)/);
                    if (m) { contestId = m[1]; taskScreenName = m[2]; break; }
                }
                if (!contestId || !taskScreenName) throw new Error('未找到 AtCoder 链接');
                window.scrollTo(0, 0);
                await new Promise(r => setTimeout(r, 80));
                const screenshot = await html2canvas(document.documentElement, {
                    width: window.innerWidth, height: window.innerHeight,
                    scale: 0.8, useCORS: true, allowTaint: true,
                    backgroundColor: null, logging: false, removeContainer: true
                });

                storeData('code', code);
                storeData('contest', contestId);
                storeData('task', taskScreenName);
                storeData('screenshot', screenshot.toDataURL('image/jpeg', 0.75));

                createOverlay();
                const img = document.getElementById('rmj-screenshot');
                if (img) {
                    img.src = screenshot.toDataURL('image/jpeg', 0.75);
                    setTimeout(() => img.classList.add('blurred'), 50);
                }

                setTimeout(() => {
                    location.href = `https://atcoder.jp/contests/${contestId}/submit?RMJ=1`;
                }, 400);
            } catch (err) {
                alert('❌ ' + err.message);
            }
        });
    }

    // ========== 洛谷：Codeforces 题目 ==========
    function initLuoguCodeforces() {
        unsafeWindow.RMJ_CF_SUBMIT = async () => {
            try {
                storeData('platform', 'codeforces');
                storeData('back', location.href);

                let code, c = document.querySelector('.cm-content'), d = {data:{}, setData(k,v){this.data[k]=v}, clearData(){}};
                c.dispatchEvent(new KeyboardEvent('keydown', {key:'a', ctrlKey:true, bubbles:true}));
                setTimeout(() => {
                    let e = new Event('copy', {bubbles:true});
                    Object.defineProperty(e, 'clipboardData', {value:d});
                    c.dispatchEvent(e);
                    code = d.data['text/plain'] || '';
                    c.dispatchEvent(new KeyboardEvent('keydown', {key:'Escape', bubbles:true}));
                }, 50);
                if (!code?.trim()) throw new Error('代码为空');

                const probMatch = href.match(/CF(\d+)([A-Z]\d*)/);
                if (!probMatch) throw new Error('无法解析题目编号');
                const contest = probMatch[1];
                const index = probMatch[2];

                const screenshot = await html2canvas(document.documentElement, {
                    width: window.innerWidth, height: window.innerHeight,
                    scale: 0.8, useCORS: true, allowTaint: true,
                    backgroundColor: null, logging: false, removeContainer: true
                });

                storeData('code', code);
                storeData('cf_contest', contest);
                storeData('cf_index', index);
                storeData('screenshot', screenshot.toDataURL('image/jpeg', 0.75));

                createOverlay();
                const img = document.getElementById('rmj-screenshot');
                if (img) {
                    img.src = screenshot.toDataURL('image/jpeg', 0.75);
                    setTimeout(() => img.classList.add('blurred'), 50);
                }

                setTimeout(() => {
                    location.href = `https://codeforces.com/problemset/submit/${contest}/${index}?RMJ=1`;
                }, 400);
            } catch (err) {
                alert('❌ ' + err.message);
            }
        };
    }

    // ========== AtCoder 提交页 ==========
    function initAtCoderSubmit() {
        document.documentElement.classList.add('rmj-loading');
        createOverlay();
        const img = document.getElementById('rmj-screenshot');
        const screenshotData = getData('screenshot');
        if (screenshotData && img) {
            img.src = screenshotData;
            img.classList.add('blurred');
        }

        const execute = () => executeCommonSubmit('atcoder');
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', execute);
        } else {
            execute();
        }
    }

    // ========== Codeforces 提交页 ==========
    function initCodeforcesSubmit() {
        document.documentElement.classList.add('rmj-loading');
        createOverlay();
        const img = document.getElementById('rmj-screenshot');
        const screenshotData = getData('screenshot');
        if (screenshotData && img) {
            img.src = screenshotData;
            img.classList.add('blurred');
        }

        const execute = () => executeCommonSubmit('codeforces');
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', execute);
        } else {
            execute();
        }
    }

    // ========== 公用提交逻辑 ==========
    async function executeCommonSubmit(platform) {
        const code = getData('code');
        if (!code?.trim()) {
            alert('代码为空');
            return;
        }

        document.documentElement.classList.remove('rmj-loading');

        // 等待表单
        let form = null;
        for (let i = 0; i < 100; i++) {
            if (platform === 'atcoder') {
                form = document.querySelector('form[action*="/submit"]');
            } else if (platform === 'codeforces') {
                const forms = document.querySelectorAll('form[action]');
                form = forms.length >= 2 ? forms[1] : null;
            }
            if (form) break;
            await new Promise(r => setTimeout(r, 100));
        }

        // 移动 Cloudflare 验证框
        const moveCF = () => {
            const el = document.querySelector(
                '.cf-challenge, .cf-turnstile, iframe[src*="challenges.cloudflare.com"], [data-callback*="turnstile"]'
            );
            if (el) {
                el.style.cssText += 'position: fixed !important; top: 50% !important; left: 50% !important; transform: translate(-50%, -50%) !important; z-index: 999999 !important;';
                return true;
            }
            return false;
        };

        for (let i = 0;; i++) {
            if (moveCF()) break;
            await new Promise(r => setTimeout(r, 500));
        }

        // 填充编辑器
        let textarea = null;
        if (platform === 'atcoder') {
            textarea = document.getElementById('plain-textarea');
        } else if (platform === 'codeforces') {
            textarea = document.querySelector('#sourceCodeTextarea');
        }

        if (textarea) {
            textarea.value = code;
            textarea.dispatchEvent(new Event('input', { bubbles: true }));
            textarea.dispatchEvent(new Event('change', { bubbles: true }));
        }

        const aceDiv = document.getElementById('editor');
        if (aceDiv && typeof unsafeWindow.ace !== 'undefined') {
            try {
                const editor = unsafeWindow.ace.edit(aceDiv);
                editor.setValue(code, 1);
                editor.clearSelection();
                editor.focus();
            } catch (e) { /* ignore */ }
        }

        // 设置语言
        if (platform === 'atcoder') {
            const task = getData('task');
            if (task) {
                const sel = document.querySelector('select[name="data.TaskScreenName"]');
                if (sel) {
                    sel.value = task;
                    sel.dispatchEvent(new Event('change', { bubbles: true }));
                }
            }
            const lang = document.querySelector('select[name="data.LanguageId"]');
            if (lang) {
                lang.value = '6017'; // C++23
                lang.dispatchEvent(new Event('change', { bubbles: true }));
            }
        } else if (platform === 'codeforces') {
            const lang = document.querySelector('select[name="programTypeId"]');
            if (lang) {
                lang.value = '91'; // G++23
                lang.dispatchEvent(new Event('change', { bubbles: true }));
            }
        }

        // 等待 Cloudflare 验证
        let verified = false;
        for (let i = 0; ; i++) {
            const tokenInput = document.querySelector('input[name^="cf-turnstile-response"]');
            if (tokenInput?.value?.length > 10) {
                verified = true;
                break;
            }
            await new Promise(r => setTimeout(r, 100));
        }

        if (!verified) {
            const content = document.getElementById('rmj-overlay-content');
            if (content) content.innerHTML = `<div id="rmj-message">⚠️ 验证超时</div>`;
            return;
        }

        // 分平台处理
        if (platform === 'atcoder') {
            // === AtCoder：继续使用 fetch 提交 ===
            const formData = new FormData(form);

            fetch(form.action, {
                method: 'POST',
                body: formData,
                credentials: 'include',
                headers: { 'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8' }
            })
            .then(() => {
                const contestId = getData('contest') || '';
                clearData();
                window.location.href = `https://www.luogu.com.cn/record/list?rmj=2&contest=${encodeURIComponent(contestId)}`;
            })
            .catch(err => {
                alert(`⚠️ AtCoder 提交失败：${err.message}`);
                clearData();
            });
        } else if (platform === 'codeforces') {
            let submitBtn = null;
            for (let i = 0; i < 50; i++) {
                submitBtn = document.querySelector('input.submit[type="submit"], button.submit');
                if (submitBtn) break;
                await new Promise(r => setTimeout(r, 100));
            }

            if (!submitBtn) {
                alert('❌ 未找到 Codeforces 提交按钮');
                clearData();
                return;
            }
            submitBtn.click();
        }
    }
})();