// ==UserScript==
// @name         zyxOT抗轰炸能力测试
// @namespace    http://tampermonkey.net/
// @version      玩命fetch
// @author       zyxOT测试组
// @match        https://zyxot.xo.je/*
// @grant        none
// ==/UserScript==

let cnt = 0;

function fet(){
    try{
        fetch("https://zyxot.xo.je/");
    }catch(e){alert("fail:${e}");}
    if ((++cnt) % 100 == 0)
        alert("${cnt}");
}

for (;;)
    setTimeout(fet,0);