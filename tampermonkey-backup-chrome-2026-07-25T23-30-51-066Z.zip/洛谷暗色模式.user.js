// ==UserScript==
// @name         洛谷暗色模式
// @namespace    http://tampermonkey.net/
// @version      4.4
// @description  洛谷调整暗色模式
// @author       cqbzzky
// @match        https://www.luogu.com.cn/*
// @match        https://luogu.com.cn/*
// @icon         https://www.luogu.com.cn/favicon.ico
// @grant        GM_addStyle
// @grant        GM_setValue
// @grant        GM_getValue
// @license     MIT
// @downloadURL https://update.greasyfork.org/scripts/564410/%E6%B4%9B%E8%B0%B7%E6%9A%97%E8%89%B2%E6%A8%A1%E5%BC%8F.user.js
// @updateURL https://update.greasyfork.org/scripts/564410/%E6%B4%9B%E8%B0%B7%E6%9A%97%E8%89%B2%E6%A8%A1%E5%BC%8F.meta.js
// ==/UserScript==

(function() {
    'use strict';

    // 修复main元素的暗色方案
    const darkStyle = `
        /* === 基础页面结构 === */
        body, #app, .main-container {
            background-color: #0d1117 !important;
            color: #c9d1d9 !important;
        }

        /* === 修复main元素 === */
        main, main[data-v-f265fec6], main[data-v-*] {
            background-color: #0d1117 !important;
            color: #c9d1d9 !important;
        }

        /* main的所有直接子元素 */
        main > * {
            color: #c9d1d9 !important;
        }

        /* 防止内部元素继承白色背景 */
        main div, main section, main article {
            color: #c9d1d9 !important;
        }

        .sidebar-container.reverse.layout {
            background-color: #0d1117 !important;
        }

        .wrapper.wrapped.lfe-body.header-layout.tiny {
            background-color: #0d1117 !important;
        }

        .ide-toolbar {
            background-color: #0d1117 !important;
        }

        .cm-gutter.cm-lineNumbers {
            background-color: #0d1117 !important;
        }

        .cm-gutter.cm-foldGutter {
            background-color: #0d1117 !important;
        }

        .text.lform-size-small {
            background-color: #0d1117 !important;
        }

        .aml-tab-list {
            background-color: #0d1117 !important;
        }

        .welcomeRight {
            background-color: #0d1117 !important;
        }

        /* === 题目页面 === */
        article {
            color: #c9d1d9 !important;
        }

        article section {
            background-color: #161b22 !important;
            border: 1px solid #30363d !important;
            border-radius: 6px;
            margin: 16px 0 !important;
            padding: 20px !important;
        }

        /* === 标题优化 === */
        article h1 {
            color: #58a6ff !important;
            border-bottom: 2px solid #30363d !important;
            padding-bottom: 12px !important;
            margin-bottom: 24px !important;
            font-size: 28px !important;
            font-weight: 700 !important;
        }

        article h2 {
            color: #f0f6fc !important;
            border-bottom: 1px solid #3d444d !important;
            padding-bottom: 10px !important;
            margin-top: 24px !important;
            margin-bottom: 16px !important;
            font-size: 22px !important;
            font-weight: 600 !important;
        }

        /* 所有标题级别 */
        h1, h2, h3, h4, h5, h6 {
            color: #f0f6fc !important;
        }

        h3 {
            color: #e6edf3 !important;
            font-size: 18px !important;
            font-weight: 600 !important;
            margin: 20px 0 12px 0 !important;
        }

        h4 {
            color: #dde1e6 !important;
            font-size: 16px !important;
            font-weight: 600 !important;
            margin: 16px 0 10px 0 !important;
        }

        /* === 导航栏 === */
        .top-bar, .header, .am-topbar, nav {
            background-color: #161b22 !important;
            border-bottom: 2px solid #30363d !important;
        }

        /* === 代码编辑器区域 === */
        .lfe-code, pre, code {
            background-color: #1c2128 !important;
            color: #c9d1d9 !important;
            border: 1px solid #30363d !important;
            border-radius: 6px;
        }

        /* === 卡片和面板 === */
        .card, .panel, .am-panel, .section,
        [class*="card"], [class*="panel"],
        [class*="container"]:not(.monaco-editor) {
            background-color: #161b22 !important;
            color: #c9d1d9 !important;
            border: 1px solid #30363d !important;
            border-radius: 6px;
        }

        /* === 通用容器修复 === */
        div[class*="main"], div[class*="content"],
        div[class*="wrapper"], div[class*="layout"] {
            color: #c9d1d9 !important;
        }

        /* 更通用的修复 - 针对所有div */
        div {
            color: #c9d1d9 !important;
        }

        /* 但允许卡片类元素保持深灰色 */
        div.card, div.panel, div[class*="card"], div[class*="panel"] {
            background-color: #161b22 !important;
        }

        /* === 按钮 === */
        button, .btn, .am-btn {
            background-color: #21262d !important;
            color: #c9d1d9 !important;
            border: 1px solid #30363d !important;
        }

        button:hover, .btn:hover, .am-btn:hover {
            background-color: #30363d !important;
        }

        /* === 输入框 === */
        input, textarea, select {
            background-color: #0d1117 !important;
            color: #c9d1d9 !important;
            border: 1px solid #30363d !important;
        }

        /* === 链接 === */
        a {
            color: #58a6ff !important;
        }

        a:hover {
            color: #79c0ff !important;
        }

        /* === 表格 === */
        table {
            background-color: #161b22 !important;
            border: 1px solid #30363d !important;
        }

        th, td {
            border: 1px solid #30363d !important;
            color: #c9d1d9 !important;
        }

        th {
            background-color: #1c2128 !important;
            color: #f0f6fc !important;
            font-weight: 600 !important;
        }

        /* === 数学公式 === */
        .katex, .katex-display {
            color: #c9d1d9 !important;
            background: transparent !important;
        }

        /* === 编辑器 === */
        .monaco-editor, .code-editor {
            background-color: #1e1e1e !important;
        }

        /* === 讨论区 === */
        .comment, .discussion, .feeds {
            background-color: #161b22 !important;
            border: 1px solid #30363d !important;
        }

        /* === 滚动条 === */
        ::-webkit-scrollbar {
            width: 12px;
            height: 12px;
        }

        ::-webkit-scrollbar-track {
            background: #0d1117;
        }

        ::-webkit-scrollbar-thumb {
            background: #30363d;
            border-radius: 6px;
        }

        ::-webkit-scrollbar-thumb:hover {
            background: #484f58;
        }

        /* === 阴影效果 === */
        * {
            box-shadow: none !important;
            text-shadow: none !important;
        }

        /* === 文字对比度优化 === */
        p, li, div, span {
            color: #c9d1d9 !important;
        }

        strong, b {
            color: #e6edf3 !important;
            font-weight: 700 !important;
        }

        em, i {
            color: #d4d8dd !important;
        }

        /* === 列表 === */
        ul, ol {
            color: #c9d1d9 !important;
        }

        li {
            color: #c9d1d9 !important;
            margin: 6px 0 !important;
        }

        /* === 特殊文本 === */
        .text-muted, .text-secondary {
            color: #8b949e !important;
        }

        .text-primary {
            color: #58a6ff !important;
        }

        .text-success {
            color: #3fb950 !important;
        }

        .text-warning {
            color: #d29922 !important;
        }

        .text-danger {
            color: #f85149 !important;
        }

        /* === 代码区域 === */
        .lfe-codemirror, .cm-editor,
        .input-wrapper, .output-wrapper {
            background-color: #1c2128 !important;
            border: 1px solid #30363d !important;
        }
    `;

    let isDarkMode = GM_getValue('luoguDarkMode', false);
    let darkStyleElement = null;

    function applyDarkMode() {
        if (!darkStyleElement) {
            darkStyleElement = document.createElement('style');
            darkStyleElement.id = 'luogu-dark-mode-style';
            darkStyleElement.textContent = darkStyle;
            document.head.appendChild(darkStyleElement);
        } else {
            darkStyleElement.disabled = false;
        }

        // 特别处理main元素
        setTimeout(() => {
            // 处理所有main元素
            document.querySelectorAll('main').forEach(mainEl => {
                mainEl.style.backgroundColor = '#0d1117';
                mainEl.style.color = '#c9d1d9';

                // 处理main内部的元素
                mainEl.querySelectorAll('div, section, article').forEach(el => {
                    const computedStyle = window.getComputedStyle(el);
                    const bgColor = computedStyle.backgroundColor;

                    // 如果是白色或浅色背景，改为暗色
                    if (isLightColor(bgColor)) {
                        el.style.backgroundColor = '#0d1117';
                        el.style.color = '#c9d1d9';
                    }
                });
            });

            // 处理标题
            document.querySelectorAll('h1, h2, h3, h4, h5, h6').forEach(el => {
                el.style.color = '#f0f6fc';
                el.style.fontWeight = '600';
            });
        }, 300);
    }

    function removeDarkMode() {
        if (darkStyleElement) {
            darkStyleElement.disabled = true;
        }

        // 恢复main元素的样式
        document.querySelectorAll('main').forEach(mainEl => {
            mainEl.style.backgroundColor = '';
            mainEl.style.color = '';

            mainEl.querySelectorAll('div, section, article').forEach(el => {
                el.style.backgroundColor = '';
                el.style.color = '';
            });
        });

        // 恢复标题
        document.querySelectorAll('h1, h2, h3, h4, h5, h6').forEach(el => {
            el.style.color = '';
            el.style.fontWeight = '';
        });
    }

    function isLightColor(color) {
        if (!color || color === 'rgba(0, 0, 0, 0)' || color === 'transparent') {
            return false;
        }

        // 解析颜色值
        let r, g, b;

        if (color.startsWith('rgb')) {
            const match = color.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)/);
            if (match) {
                r = parseInt(match[1]);
                g = parseInt(match[2]);
                b = parseInt(match[3]);
            }
        } else if (color.startsWith('#')) {
            const hex = color.substring(1);
            if (hex.length === 3) {
                r = parseInt(hex[0] + hex[0], 16);
                g = parseInt(hex[1] + hex[1], 16);
                b = parseInt(hex[2] + hex[2], 16);
            } else if (hex.length === 6) {
                r = parseInt(hex.substring(0, 2), 16);
                g = parseInt(hex.substring(2, 4), 16);
                b = parseInt(hex.substring(4, 6), 16);
            }
        }

        if (r === undefined) return false;

        // 计算亮度
        const brightness = (r * 299 + g * 587 + b * 114) / 1000;
        return brightness > 160;
    }

    // 创建可拖动的按钮
    // 创建可拖动的按钮
    function createDraggableButton() {
        // 移除旧按钮
        const oldBtn = document.getElementById('luogu-dark-mode-toggle');
        if (oldBtn) oldBtn.remove();

        const isDark = GM_getValue('luoguDarkMode', false);
        const savedPosition = GM_getValue('buttonPosition', { x: 20, y: 20 });

        const button = document.createElement('button');
        button.id = 'luogu-dark-mode-toggle';
        button.innerHTML = isDark ? '☀️ 亮色' : '🌙 暗色';
        button.title = '点击切换模式，长按拖动';

        // 按钮样式
        Object.assign(button.style, {
            position: 'fixed',
            top: `${savedPosition.y}px`,
            left: `${savedPosition.x}px`,
            zIndex: '99999',
            padding: '8px 16px',
            backgroundColor: isDark ? '#58a6ff' : '#21262d',
            color: 'white',
            border: 'none',
            borderRadius: '8px',
            cursor: 'grab',
            fontSize: '13px',
            fontWeight: '600',
            boxShadow: '0 3px 10px rgba(0,0,0,0.3)',
            fontFamily: 'system-ui, -apple-system, sans-serif',
            userSelect: 'none',
            touchAction: 'none'
        });

        // 拖动状态变量
        let isDragging = false;
        let dragStartTime = 0;
        let dragDistance = 0;
        let startX = 0, startY = 0, initialLeft = 0, initialTop = 0;

        // 开始拖动
        function startDrag(e) {
            isDragging = false; // 先设为false，等待判断
            dragStartTime = Date.now();
            dragDistance = 0;

            // 获取起始位置
            if (e.type === 'mousedown') {
                startX = e.clientX;
                startY = e.clientY;
            } else if (e.type === 'touchstart') {
                startX = e.touches[0].clientX;
                startY = e.touches[0].clientY;
            }

            // 获取按钮当前位置
            const rect = button.getBoundingClientRect();
            initialLeft = rect.left;
            initialTop = rect.top;

            // 阻止默认行为
            e.preventDefault();
            e.stopPropagation();

            // 添加移动和结束事件的监听
            document.addEventListener('mousemove', onDragMove);
            document.addEventListener('touchmove', onDragMove, { passive: false });
            document.addEventListener('mouseup', endDrag);
            document.addEventListener('touchend', endDrag);

            // 更新按钮样式
            button.style.cursor = 'grabbing';
            button.style.opacity = '0.9';
        }

        // 拖动移动
        function onDragMove(e) {
            let clientX, clientY;

            if (e.type === 'mousemove') {
                clientX = e.clientX;
                clientY = e.clientY;
            } else if (e.type === 'touchmove') {
                clientX = e.touches[0].clientX;
                clientY = e.touches[0].clientY;
            }

            // 计算移动距离
            const deltaX = clientX - startX;
            const deltaY = clientY - startY;
            const distance = Math.sqrt(deltaX * deltaX + deltaY * deltaY);

            // 如果移动距离超过阈值，认为是拖动
            if (distance > 5) {
                isDragging = true;
                dragDistance = distance;

                // 计算新位置
                let newLeft = initialLeft + deltaX;
                let newTop = initialTop + deltaY;

                // 限制在可视区域内
                const maxX = window.innerWidth - button.offsetWidth;
                const maxY = window.innerHeight - button.offsetHeight;

                newLeft = Math.max(0, Math.min(newLeft, maxX));
                newTop = Math.max(0, Math.min(newTop, maxY));

                // 应用新位置
                button.style.left = `${newLeft}px`;
                button.style.top = `${newTop}px`;
                button.style.boxShadow = '0 5px 20px rgba(0,0,0,0.5)';

                e.preventDefault();
            }
        }

        // 结束拖动
        function endDrag(e) {
            // 移除事件监听
            document.removeEventListener('mousemove', onDragMove);
            document.removeEventListener('touchmove', onDragMove);
            document.removeEventListener('mouseup', endDrag);
            document.removeEventListener('touchend', endDrag);

            // 恢复按钮样式
            button.style.cursor = 'grab';
            button.style.boxShadow = '0 3px 10px rgba(0,0,0,0.3)';
            button.style.opacity = '1';

            // 如果是拖动操作，保存位置
            if (isDragging && dragDistance > 5) {
                const rect = button.getBoundingClientRect();
                GM_setValue('buttonPosition', {
                    x: rect.left,
                    y: rect.top
                });

                // 阻止点击事件触发
                e.preventDefault();
                e.stopPropagation();
                return;
            }

            // 如果不是拖动，执行点击操作
            // 检查是否只是短暂的按下（小于300ms）
            const dragDuration = Date.now() - dragStartTime;
            if (dragDuration < 300 && dragDistance <= 5) {
                // 这是点击，切换模式
                toggleMode();
            }

            e.stopPropagation();
        }

        // 切换模式函数
        function toggleMode() {
            const newIsDark = !isDarkMode;
            GM_setValue('luoguDarkMode', newIsDark);

            if (newIsDark) {
                applyDarkMode();
                button.innerHTML = '☀️ 亮色';
                button.style.backgroundColor = '#58a6ff';
            } else {
                removeDarkMode();
                button.innerHTML = '🌙 暗色';
                button.style.backgroundColor = '#21262d';
            }

            isDarkMode = newIsDark;
        }

        // 绑定开始拖动事件
        button.addEventListener('mousedown', startDrag);
        button.addEventListener('touchstart', startDrag, { passive: false });

        // 点击事件 - 使用传统点击，但会被拖动阻止
        button.addEventListener('click', function(e) {
            // 如果isDragging为true，说明这是拖动后的误触，忽略
            if (isDragging) {
                e.preventDefault();
                e.stopPropagation();
                return;
            }
        });

        // 悬停效果
        button.addEventListener('mouseenter', () => {
            if (!isDragging) {
                button.style.transform = 'scale(1.05)';
                button.style.transition = 'transform 0.2s ease';
            }
        });

        button.addEventListener('mouseleave', () => {
            button.style.transform = 'scale(1)';
        });

        document.body.appendChild(button);
        return button;
    }

    // 主逻辑
    function init() {
        if (isDarkMode) {
            applyDarkMode();
        }

        // 创建可拖动按钮
        createDraggableButton();

        // 监听页面变化
        const observer = new MutationObserver(() => {
            if (isDarkMode) {
                setTimeout(applyDarkMode, 100);
            }

            // 如果按钮消失了，重新创建
            if (!document.getElementById('luogu-dark-mode-toggle')) {
                createDraggableButton();
            }
        });

        observer.observe(document.body, {
            childList: true,
            subtree: true
        });
    }

    // 启动
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

})();