// ==UserScript==
// @name         Competitive Companion for Vjudge
// @namespace    http://tampermonkey.net/
// @version      1.0.3
// @description  从Vjudge上爬取样例数据，仅保证Sublime Text的FastOlympicCodingHook能正确获取被爬取的数据
// @author       zyx2012
// @match        *://vjudge.net/*
// @grant        GM_xmlhttpRequest
// @license      MIT
// @downloadURL https://update.greasyfork.org/scripts/574323/Competitive%20Companion%20for%20Vjudge.user.js
// @updateURL https://update.greasyfork.org/scripts/574323/Competitive%20Companion%20for%20Vjudge.meta.js
// ==/UserScript==

function select(){
    let a = [];
    let tables = document.querySelectorAll("#frame-description");
    if (!tables.length)
        tables = document.querySelectorAll("#frame-description-container > iframe");
    let DOCUMENT = tables[tables.length - 1].contentDocument;
    tables.forEach((elem) => {
        if (elem.style.display != "none")
            DOCUMENT = elem.contentDocument;
    });
    tables = DOCUMENT.querySelectorAll(".vjudge_sample");
    tables.forEach((elem) => {
        elem.querySelectorAll("tbody").forEach((element) => {
            let input = ``,output = ``,vis = 0;
            element.querySelectorAll("pre").forEach((elem2) => {
                if (vis)
                    output = elem2.textContent + '\n';
                else
                    input = elem2.textContent + '\n',vis = 1;
            });
            const json = {
                "input": input,
                "output": output
            };
            a.push(json);
        });
    });
    if (!a.length) return ;
    const testData = {
        "tests": a
    };
/*    a.forEach((elem) => {
        alert(elem.input),alert(elem.output);
    });*/

    GM_xmlhttpRequest({
        method: "POST",
        url: "http://localhost:12345",
        headers: {
            "Content-Type": "application/json"
        },
        data: JSON.stringify(testData),
        onload: function(response) {
            console.log("Data sent successfully:", response);
        },
        onerror: function(error) {
            console.error("Error sending data:", error);
        }
    });
}//*/

let nowid = 0;

function main(){
    let element = document.querySelector("#navbarResponsive > ul.navbar-nav.top-nav-primary");
    if (!element) return ;
    const elem = document.createElement("li");
    elem.removeEventListener("click", select);
    elem.className = "nav-item";
    elem.innerHTML = `<a class="nav-link">爬取样例</a>`;
    elem.style.userSelect = "none";
    function modify(){
        let qid = ++nowid;
        elem.innerHTML = `<a class="nav-link"><i class="fa fa-refresh fa-spin" data-bs-toggle="tooltip"></i>爬取中</a>`;
        select();
        elem.innerHTML = `<a class="nav-link"><i class="fa fa-check text-success" data-bs-toggle="tooltip"></i>爬取成功</a>`;
        setTimeout(() => {
            if (qid == nowid)
                elem.innerHTML = `<a class="nav-link">爬取样例</a>`;
        },5000);
    }
    elem.addEventListener("click", modify);
    element.append(elem);
}

main();