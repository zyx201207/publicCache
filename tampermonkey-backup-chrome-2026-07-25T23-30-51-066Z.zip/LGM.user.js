// ==UserScript==
// @name         LGM
// @version      2026-05-13
// @description  把你变成LGM
// @author       zyx2012
// @match        *://codeforces.com/*
// @icon         https://codeforces.com/codeforces.org/s/50178/apple-icon-60x60.png
// @grant        none
// ==/UserScript==

let username = document.querySelector("#header > div.lang-chooser > div:nth-child(2) > a:nth-child(1)").innerHTML;
let LGM = `<span class="legendary-user-first-letter">${username[0]}</span>${username.substr(1,username.length - 1)}`;

document.querySelectorAll(".rated-user").forEach((elem) => {
    if (elem.textContent == username)
        elem.className="rated-user user-legendary",
        elem.innerHTML = LGM;
});
if (document.querySelectorAll(".friendStar").length == 0)
    document.querySelectorAll(".user-rank").forEach((elem) => {elem.innerHTML = `<span class="user-legendary">Legendary Grandmaster </span>`;});
