// ==UserScript==
// @name         dmyrank
// @namespace    http://tampermonkey.net/
// @version      1.0.0
// @description  统计dmy排行榜
// @author       zyx2012
// @match        *://newoj.daimayuan.top/calcrank
// @icon         https://newoj.daimayuan.top/favicon-96x96.png
// @grant        none
// ==/UserScript==

async function main(){
    let elem = document.querySelector(".empty");
    elem.innerHTML = `<h1>比赛链接</h1>
    <div id="input_area" style="min-width: 100%;">
    <p><textarea style="width: 50%; border-radius: 6px;" id="input_0"></textarea></p>
    </div>
    <a class="btn">统计</a>
    <textarea style="min-height: 70%; width: 50%; padding: 16px; border-radius: 6px;" placeholder="结果" id="output" readonly=""></textarea>`;
    let elem2 = elem.querySelector("#input_area");
    let topid = 0,iframeseq = new Map();
    elem.querySelector(".btn").addEventListener("click", () => {
        let ansMap = new Map();
        elem2.querySelectorAll("textarea").forEach((elem) => {
            let iframe = iframeseq.get(elem.id);
            let elemv = iframe.contentDocument.querySelector("body > div.page > div > div > div > div > div > div > div:nth-child(2) > div > div > table:nth-child(2) > tbody");
            elemv.querySelectorAll("tr").forEach((elem) => {
                let name = elem.querySelector(".col--user").textContent.trim(),val = 0;
                elem.querySelectorAll(".col--problem").forEach((value) => {
                    if (value.textContent.trim()[0] == "-"){
                        return ;
                    }
                    val += Number(value.firstElementChild.textContent);
                });
                if (!ansMap.has(name))
                    ansMap.set(name,val);
                else
                    ansMap.set(name,ansMap.get(name) + val);
            });
        });
        let ary = [];
        for (let val of ansMap)
            ary.push({"name":val[0],"score":val[1]});
        ary.sort((a,b) => {b.score - a.score;});
        let top = 0,output = document.querySelector("#output");
        output.value = ``;
        ary.forEach((v) => {
            output.value += `${++top}|${v.name} ${v.score}
`
        });
;
    });
    function load(){
        elem2.querySelectorAll("textarea").forEach((elem) => {
            let iframe = iframeseq.get(elem.id);
            iframe.style.display = "none";
            document.body.append(iframe);
        });
    }
    function domain(){
        let top = 0;
        elem2.querySelectorAll("textarea").forEach((elem) => {
            elem.oninput = () => {
                if (elem.value[elem.value.length - 1] == '\n'){
                    elem.value = elem.value.substr(0,elem.value.length - 1);
                    let val = document.createElement("textarea");
                    elem2.append(val);
                    val.outerHTML = `<p><textarea style="width: 50%; border-radius: 6px;" id="input_${topid++}"></textarea></p>`;
                    val.focus();
                    val.setSelectionRange(0,0);
                    domain();
                    return ;
                }
                if (elem.value == ""&&elem2.querySelectorAll("textarea").length > 1){
                    elem.remove();
                    return ;
                }
                let iframe = document.createElement("iframe");
                iframe.src = elem.value;
                iframeseq.set(elem.id,iframe);
                load();
            };
        });
    }
    domain();
    load();
}
main();