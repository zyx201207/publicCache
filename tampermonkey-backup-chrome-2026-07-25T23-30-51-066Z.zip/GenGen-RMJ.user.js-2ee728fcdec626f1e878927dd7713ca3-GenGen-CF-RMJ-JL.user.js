// ==UserScript==
// @name         GenGen-CF-RMJ-JL
// @namespace    http://tampermonkey.net/
// @version      3.1.2.4
// @author       GenGen 队
// @match        https://www.luogu.com.cn/record/list*
// @grant        GM_xmlhttpRequest
// @grant        GM_setValue
// @grant        GM_getValue
// @connect      codeforces.com
// @run-at       document-end
// @description  GenGen RMJ （Codeforces 记录）
// ==/UserScript==

(async function () {
  'use strict';
  if (document.readyState !== 'complete')
    await new Promise(r => addEventListener('load', r, { once: true }));
  const startTime = Date.now();
  const params = new URLSearchParams(window.location.search);
  const rmj = params.get('rmj');
  const pid = params.get('pid') || '';

  if (rmj !== '1') return;

  // ========== 配置 ==========
  const STATUS_MAP = {
    'OK': { full: 'Accepted', cls: 'cf-status-accepted' },
    'WRONG_ANSWER': { full: 'Wrong Answer', cls: 'cf-status-wrong' },
    'COMPILATION_ERROR': { full: 'Compilation Error', cls: 'cf-status-ce' },
    'RUNTIME_ERROR': { full: 'Runtime Error', cls: 'cf-status-re' },
    'TIME_LIMIT_EXCEEDED': { full: 'Time Limit Exceeded', cls: 'cf-status-limit' },
    'MEMORY_LIMIT_EXCEEDED': { full: 'Memory Limit Exceeded', cls: 'cf-status-limit' },
    'OUTPUT_LIMIT_EXCEEDED': { full: 'Output Limit Exceeded', cls: 'cf-status-limit' },
    'TESTING': { full: 'Running', cls: 'cf-status-running' }
  };

  // ========== 注入样式 ==========
  const style = document.createElement('style');
  style.textContent = `
    .cf-card { display: flex; align-items: center; font-size: 16px; padding: 10px 0; border-bottom: 1px solid #eee; }
    .cf-avatar img { width: 36px; height: 36px; border-radius: 50%; margin-right: 12px; }
    .cf-nameblock { display: flex; flex-direction: column; width: 180px; margin-right: 12px; }
    .cf-name { font-weight: bold; color: #333; font-size: 16px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .cf-time { font-size: 14px; color: #888; line-height: 1.2; margin-top: 2px; white-space: nowrap; }
    .cf-status { flex: 0 0 auto; margin-right: 12px; text-align: left; width: 250px; }
    .cf-status span {
      border-radius: 2px;
      padding: 2px 3px;
      font-size: 14px;
      font-weight: 600;
      white-space: nowrap;
      display: inline-flex;
      align-items: center;
      position: relative;
      max-width: 100%;
      overflow: hidden;
      text-overflow: ellipsis;
      box-sizing: border-box;
    }
    .cf-status-text {
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
    .cf-status-subtext {
      position: absolute;
      top: -2px;
      right: 2px;
      font-size: 10px!important;
      color: rgba(255, 255, 255, 0.8);
      font-weight: bold;
      line-height: 1;
      pointer-events: none;
    }
    .cf-status-accepted { background: rgb(82, 196, 26); color: #fff; }
    .cf-status-wrong { background: rgb(231, 76, 60); color: #fff; }
    .cf-status-re { background: rgb(157, 61, 207); color: #fff; }
    .cf-status-ce { background: rgb(250, 219, 20); color: #fff; }
    .cf-status-limit { background: rgb(5, 34, 66); color: #fff; }
    .cf-status-running { background: #888; color: #fff; }
    .cf-status-other { background: rgb(243, 156, 17); color: #fff; }
    .cf-problem { flex: 1; color: rgb(52, 152, 219); font-size: 16px; text-align: left; min-width: 100px; margin-left: 60px; }
    .cf-error { padding: 10px; color: #e74c3c; font-weight: bold; }
    .cf-loading { padding: 10px; color: ＃708090; font-weight: bold; }
  `;
  document.head.appendChild(style);

  // ========== 工具函数 ==========
  function getLuoguUserInfo() {
    const nameEl = document.querySelector('#app .user-nav > a > span') ||
                   document.querySelector('div.header span a span') ||
                   document.querySelector('.username');
    const avatarEl = document.querySelector('#app .user-nav a img');
    return {
      name: (nameEl?.textContent || 'User').trim(),
      color: nameEl?.style?.color || '#333',
      avatar: (avatarEl?.src || 'https://cdn.luogu.com.cn/upload/usericon/default.png').trim()
    };
  }

  function formatVerdict(verdict) {
    if (STATUS_MAP[verdict]) return STATUS_MAP[verdict];
    return {
      full: verdict.split('_').map(w => w.charAt(0) + w.slice(1).toLowerCase()).join(' '),
      cls: 'cf-status-other'
    };
  }

  function createCfCard(taskDisplay, rawStatus, timeText, cfUrl, luoguUrl, passedTestCount, id = '') {
    const card = document.createElement('div');
    card.className = 'cf-card';
    if (id) card.dataset.id = id;

    const { name, color, avatar } = getLuoguUserInfo();
    const avatarDiv = document.createElement('div');
    avatarDiv.className = 'cf-avatar';
    const img = document.createElement('img');
    img.src = avatar;
    img.onerror = () => img.src = 'https://cdn.luogu.com.cn/upload/usericon/1.png';
    avatarDiv.appendChild(img);

    const nameBlock = document.createElement('div');
    nameBlock.className = 'cf-nameblock';
    const nameDiv = document.createElement('div');
    nameDiv.className = 'cf-name';
    nameDiv.style.color = color;
    nameDiv.textContent = name;
    const timeDiv = document.createElement('div');
    timeDiv.className = 'cf-time';
    timeDiv.textContent = timeText;
    nameBlock.append(nameDiv, timeDiv);

    const statusDiv = document.createElement('div');
    statusDiv.className = 'cf-status';
    const statusLink = document.createElement('a');
    statusLink.href = cfUrl;
    statusLink.target = '_blank';
    statusLink.rel = 'noopener noreferrer';
    const span = document.createElement('span');

    const { full, cls } = formatVerdict(rawStatus);
    span.className = cls;
    // 主文字
    const textSpan = document.createElement('span');
    textSpan.className = 'cf-status-text';
    textSpan.textContent = full;
    span.appendChild(textSpan);
    if (passedTestCount != null && !isNaN(passedTestCount)) {
      const subtext = document.createElement('span');
      subtext.className = 'cf-status-subtext';

      subtext.textContent = (passedTestCount+1).toString();
      span.appendChild(subtext);
    }
    statusLink.appendChild(span);
    statusDiv.appendChild(statusLink);

    const problemDiv = document.createElement('div');
    problemDiv.className = 'cf-problem';
    const probLink = document.createElement('a');
    probLink.href = luoguUrl;
    probLink.textContent = taskDisplay;
    probLink.target = '_blank';
    probLink.rel = 'noopener noreferrer';
    problemDiv.appendChild(probLink);
    card.append(avatarDiv, nameBlock, statusDiv, problemDiv);
    return card;
  }

  // ========== 缓存处理（加固）==========
  function getCache() {
    try {
      const raw = GM_getValue('cf-submissions-cache', '[]');
      const parsed = JSON.parse(raw);
      return Array.isArray(parsed) ? parsed : [];
    } catch (e) {
      console.warn('[Gen-CF-RMJ] 缓存解析失败，重置');
      return [];
    }
  }

  function saveCache(cache) {
    if (!Array.isArray(cache)) cache = [];
    GM_setValue('cf-submissions-cache', JSON.stringify(cache));
  }

  // ========== 获取 CF handle ==========
  function getCFHandle(callback) {
    GM_xmlhttpRequest({
      method: 'GET',
      url: 'https://codeforces.com/',
      withCredentials: true,
      onload: function(res) {
        if (res.status !== 200) return callback(null);
        try {
          const doc = new DOMParser().parseFromString(res.responseText, 'text/html');
          const userLink = doc.querySelector('#header > div.lang-chooser > div:nth-child(2) > a:nth-child(1)');
          if (!userLink) return callback(null);
          const text = userLink.textContent.trim();
          if (text === 'Enter') callback(null);
          else callback(text);
        } catch (e) {
          callback(null);
        }
      },
      onerror: () => callback(null),
      timeout: 8000
    });
  }

  // ========== 获取提交记录 ==========
  async function fetchCFSubmissions(handle) {
    return new Promise((resolve, reject) => {
      const timeout = setTimeout(() => reject(new Error('Timeout')), 8000);
      GM_xmlhttpRequest({
        method: 'GET',
        url: `https://codeforces.com/api/user.status?handle=${encodeURIComponent(handle)}&from=1`,
        onload: res => {
          clearTimeout(timeout);
          if (res.status !== 200) return reject(new Error(`HTTP ${res.status}`));
          try {
            const data = JSON.parse(res.responseText);
            if (data.status !== 'OK') return reject(new Error(data.comment || 'API error'));
            resolve(data.result || []);
          } catch (err) {
            reject(err);
          }
        },
        onerror: () => {
          clearTimeout(timeout);
          reject(new Error('Network error'));
        }
      });
    });
  }

  // ========== 渲染 ==========
  function updateRecordCount(count) {
    const countSpan = document.querySelector('#app > div.main-container > main > div > section > div > div > span > span');
    if (countSpan) {
      countSpan.textContent = (count || 0).toString();
    }
  }

  function renderCache(cache, mainDiv) {
    let filtered = cache;
    if (searchFilter) {
      // 🔥 关键修改：不再移除 "CF" 前缀！
      const normQuery = searchFilter.toLowerCase();
      filtered = cache.filter(s => s.taskDisplay && s.taskDisplay.toLowerCase().includes(normQuery));
    }

    displayedIds.clear();

    mainDiv.innerHTML = '';
    updateRecordCount(filtered.length);

        if (filtered.length === 0) {
      const elapsed = Date.now() - startTime; 
      const msg = document.createElement('div');
      if (elapsed < 5000) {
        msg.className = 'cf-loading';
        msg.textContent = '加载中...';
      } else {
        msg.className = 'cf-error';
        msg.textContent = '没有提交记录';
      }
      mainDiv.appendChild(msg);
    } else {
      filtered.forEach(sub => {
        const timeText = new Date((sub.timestamp || 0) * 1000).toLocaleString('zh-CN');
        const card = createCfCard(
          sub.taskDisplay || 'Unknown Problem',
          sub.verdict || 'UNKNOWN',
          timeText,
          sub.cfSubmissionUrl || '#',
          sub.luoguProblemUrl || '#',
          sub.passedTestCount,
          sub.id || ''
        );
        displayedIds.add(sub.id);
        mainDiv.appendChild(card);
      });
    }
  }

  function waitForElement(selector, timeout = 10000) {
    return new Promise((resolve, reject) => {
      const el = document.querySelector(selector);
      if (el) return resolve(el);
      const observer = new MutationObserver(() => {
        const found = document.querySelector(selector);
        if (found) {
          observer.disconnect();
          resolve(found);
        }
      });
      observer.observe(document.body, { childList: true, subtree: true });
      setTimeout(() => {
        observer.disconnect();
        reject(new Error(`Timeout: ${selector}`));
      }, timeout);
    });
  }

  // ========== 主流程 ==========
  let displayedIds = new Set();
  let searchFilter = pid;

  async function bindSearch(mainDiv) {
    try {
      const input = await waitForElement('#app main section div section:nth-child(1) div div:nth-child(1) input', 8000);
      input.value = searchFilter;
      const originalOnInput = input.oninput;
      input.oninput = (e) => {
        searchFilter = e.target.value.trim();
        const url = new URL(window.location);
        if (searchFilter) url.searchParams.set('pid', searchFilter);
        else url.searchParams.delete('pid');
        history.replaceState(null, '', url);
        renderCache(getCache(), mainDiv);
        originalOnInput?.call(input, e);
      };
    } catch (e) {
      console.warn('[Gen-CF-RMJ] 搜索框未找到');
    }
  }


  let mainDivCached = null;
  async function mainWithPolling() {
    let mainDiv;
    try {
      mainDiv = await waitForElement('main > div > div', 10000);
    } catch {
      const appMain = document.querySelector('#app main') || document.body;
      mainDiv = document.createElement('div');
      appMain.appendChild(mainDiv);
    }
    mainDivCached = mainDiv;

    // 初始渲染
    renderCache(getCache(), mainDiv);
    await bindSearch(mainDiv);
    function updateNow() {
      getCFHandle(async (handle) => {
        if (!handle) return;
        try {
          const submissions = await fetchCFSubmissions(handle);
          const normalized = submissions.map(sub => ({
            id: String(sub.id),
            taskDisplay: `CF${sub.contestId}${sub.problem.index} - ${sub.problem.name}`,
            verdict: sub.verdict || 'UNKNOWN',
            timestamp: sub.creationTimeSeconds,
            cfSubmissionUrl: `https://codeforces.com/contest/${sub.contestId}/submission/${sub.id}`,
            luoguProblemUrl: `https://www.luogu.com.cn/problem/CF${sub.contestId}${sub.problem.index}`,
            passedTestCount: sub.passedTestCount
          }));

          const seen = new Set();
          const deduped = normalized.filter(item => {
            if (seen.has(item.id)) return false;
            seen.add(item.id);
            return true;
          });

          saveCache(deduped);
          renderCache(deduped, mainDiv);
        } catch (err) {
          console.warn('[Gen-CF-RMJ] 自动更新失败:', err.message || err);
        }
      });
    }

    updateNow();               // 立即执行
    setInterval(updateNow, 1000);
  }
  mainWithPolling().catch(console.error);
})();