<!doctype html>
<html lang="zh-CN">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>热门脚本 - Greasy Fork 中文镜像</title>
    <link rel="icon" type="image/png" href="/assets/logo.png">
    <link rel="stylesheet" href="https://cdn.bootcdn.net/ajax/libs/bulma/1.0.2/css/bulma.min.css">
    <link rel="stylesheet" href="https://cdn.bootcdn.net/ajax/libs/highlight.js/11.9.0/styles/github.min.css">
    <link rel="stylesheet" href="/assets/app.css">
</head>
<body>
<header class="site-header">
    <div class="container">
        <nav class="level is-mobile">
            <div class="level-left">
                <a class="brand" href="/index.php">Greasy Fork</a>
                <span class="mirror-tag">简体中文镜像</span>
                <span class="site-notice">此网站仅供临时使用，随时会关闭，请添加QQ交流群：1051811266</span>
            </div>
        </nav>
        <form class="search-box" action="/index.php" method="get">
            <input class="input" type="search" name="q" value="" placeholder="搜索用户脚本、网站或功能">
            <button class="button is-link" type="submit">搜索</button>
        </form>
        <div class="site-filter">
            <span>常用网站：</span>
                            <a href="/index.php?site=baidu.com">baidu.com</a>
                            <a href="/index.php?site=bilibili.com">bilibili.com</a>
                            <a href="/index.php?site=douyin.com">douyin.com</a>
                            <a href="/index.php?site=chaoxing.com">chaoxing.com</a>
                            <a href="/index.php?site=zhihuishu.com">zhihuishu.com</a>
                    </div>
    </div>
</header>
<main class="section">
    <div class="container">
    

<div class="columns is-variable is-5">
    <div class="column">
        <div class="list-heading">
            <div>
                <h1 class="title is-4">热门脚本</h1>
                <p class="has-text-grey">第 1 页</p>
            </div>
                    </div>

        
        <div class="script-list">
                                            <article class="script-row">
                    <h2>
                                                    <a class="script-title" href="/script.php?key=563321-all-in-one-video-downloader-hd-youtube-tiktok-instagram-x-more">多合一视频下载器（支持：YouTube, TikTok, Instagram等）</a>
                                            </h2>
                    <p class="script-description">一款多合一、快速且免费的在线视频下载器。支持从 YouTube、TikTok、抖音、Instagram、Facebook、Threads、TED、小红书、X（Twitter）等平台下载视频。享受无水印、高质量、流畅便捷的下载体验</p>
                    <div class="meta-line">
                        <span>今日安装 312</span>
                        <span>总安装 5万</span>
                        <span>更新 2026-06-15</span>
                                                    <span>版本 1.0.15</span>
                                            </div>
                </article>
                                            <article class="script-row">
                    <h2>
                                                    <a class="script-title" href="/script.php?key=446342-telegram-media-downloader">Telegram 受限图片视频下载器</a>
                                            </h2>
                    <p class="script-description">从禁止下载的Telegram频道中下载图片、视频及语音消息</p>
                    <div class="meta-line">
                        <span>今日安装 226</span>
                        <span>总安装 22.3万</span>
                        <span>更新 2026-03-09 <span class="stale-update">太久没更新</span></span>
                                                    <span>版本 1.212</span>
                                            </div>
                </article>
                                            <article class="script-row">
                    <h2>
                                                    <a class="script-title" href="/script.php?key=575364-stripview-%E9%80%8F%E8%A7%86%E9%95%9C">StripView 透视镜</a>
                                            </h2>
                    <p class="script-description">Reveal video plugin</p>
                    <div class="meta-line">
                        <span>今日安装 224</span>
                        <span>总安装 3,510</span>
                        <span>更新 2026-07-16</span>
                                                    <span>版本 9.9.15</span>
                                            </div>
                </article>
                                            <article class="script-row">
                    <h2>
                                                    <a class="script-title" href="/script.php?key=560618-youtube-improvements-layout-video-enhancer">YouTube 改进 – 布局与视频增强</a>
                                            </h2>
                    <p class="script-description">一个用于增强 YouTube 的用户脚本，提供多项实用功能，包括：优化的视频详情页布局、视频下载、视频截图、深色/浅色主题切换、视频快进控制等。</p>
                    <div class="meta-line">
                        <span>今日安装 212</span>
                        <span>总安装 4.9万</span>
                        <span>更新 2026-05-28</span>
                                                    <span>版本 1.1.5</span>
                                            </div>
                </article>
                                            <article class="script-row">
                    <h2>
                                                    <a class="script-title" href="/script.php?key=575704-telegram-media-downloader-optimized-enhanced">Telegram图片视频下载器 (优化加强版)</a>
                                            </h2>
                    <p class="script-description">支持从限制下载的 Telegram 频道中获取图片、视频及语音消息，界面设计与 Telegram 原生风格高度统一</p>
                    <div class="meta-line">
                        <span>今日安装 197</span>
                        <span>总安装 1.5万</span>
                        <span>更新 2026-07-14</span>
                                                    <span>版本 1.0.3</span>
                                            </div>
                </article>
                                            <article class="script-row">
                    <h2>
                                                    <a class="script-title" href="/script.php?key=537189-%E5%85%A8%E7%BD%91vip%E8%A7%86%E9%A2%91%E5%85%8D%E8%B4%B9%E7%A0%B4%E8%A7%A3%E5%8E%BB%E5%B9%BF%E5%91%8A-%E6%9C%80%E6%96%B03-1">全网VIP视频免费破解去广告【最新3.1】</a>
                                            </h2>
                    <p class="script-description">全网VIP视频免费破解去广告，适配PC+移动，全网VIP视频解析：爱奇艺、腾讯、优酷、bilibili等视频免费解析！🔥真4K高清🔥【脚本长期维护更新，完全免费，无广告，仅限学习交流！！】</p>
                    <div class="meta-line">
                        <span>今日安装 150</span>
                        <span>总安装 6.6万</span>
                        <span>更新 2026-06-09</span>
                                                    <span>版本 3.1.9</span>
                                            </div>
                </article>
                                            <article class="script-row">
                    <h2>
                                                    <a class="script-title" href="/script.php?key=543471-export-chatgpt-gemini-grok-conversations-as-markdown">Export ChatGPT/Gemini/Grok conversations as Markdown</a>
                                            </h2>
                    <p class="script-description">将 ChatGPT 和 Grok 网站的聊天记录导出为普通 Markdown 格式，可在 Typora 中准确打开。</p>
                    <div class="meta-line">
                        <span>今日安装 137</span>
                        <span>总安装 4.5万</span>
                        <span>更新 2025-07-24 <span class="stale-update">太久没更新</span></span>
                                                    <span>版本 1.1.1</span>
                                            </div>
                </article>
                                            <article class="script-row">
                    <h2>
                                                    <a class="script-title" href="/script.php?key=574417-2026-all-in-one-video-downloader-youtube-tiktok-x-twitter-instagram-facebook">🔥 多合一视频下载器【2026最新】- 支持 YouTube, TikTok, X(Twitter), Instagram, Facebook</a>
                                            </h2>
                    <p class="script-description">【2026最新】一键下载 YouTube, TikTok, X(Twitter), Instagram, Facebook 视频。支持 4K, 1080P, MP3, MP4，无水印，极速稳定。</p>
                    <div class="meta-line">
                        <span>今日安装 128</span>
                        <span>总安装 1.3万</span>
                        <span>更新 2026-05-14 <span class="stale-update">太久没更新</span></span>
                                                    <span>版本 2026.05.14</span>
                                            </div>
                </article>
                                            <article class="script-row">
                    <h2>
                                                    <a class="script-title" href="/script.php?key=512125-%E7%BD%91%E7%9B%98%E7%9B%B4%E9%93%BE%E4%B8%8B%E8%BD%BD%E5%8A%A9%E6%89%8B-%E8%87%AA%E5%8A%A8%E6%98%BE%E7%A4%BA%E6%9A%97%E5%8F%B7">网盘直链下载助手 （自动显示暗号）</a>
                                            </h2>
                    <p class="script-description">👆👆👆👆👆👆👆 - 支持批量获取 ✅百度网盘 ✅阿里云盘 ✅天翼云盘 ✅迅雷云盘 ✅夸克网盘 ✅移动云盘 六大网盘的直链下载地址，配合 IDM，Xdown，Aria2，Curl，比特彗星等工具高效🚀🚀🚀下载，完美适配 Chrome，Edge，FireFox，360，QQ，搜狗，百分，遨游，星愿，Opera，猎豹，Vivaldi，Yandex，Kiwi 等 18 种浏览器。可在无法安装客户端的环境下使用，助手免费开源。😎</p>
                    <div class="meta-line">
                        <span>今日安装 112</span>
                        <span>总安装 7.7万</span>
                        <span>更新 2024-10-10 <span class="stale-update">太久没更新</span></span>
                                                    <span>版本 6.2.7</span>
                                            </div>
                </article>
                                            <article class="script-row">
                    <h2>
                                                    <a class="script-title" href="/script.php?key=34613-youtube-ultimate-downloader-v13-2-all-in-one-media-suite-ad-free-sponsorblock">YouTube℠ Ultimate Downloader v13.2 🚀 — All-in-One Media Suite 🌍🎥🎵 | Ad-Free + SponsorBlock 🛡</a>
                                            </h2>
                    <p class="script-description">Adds a floating button to download YouTube videos, Shorts, and music in high quality, with an automatic system integrated with SponsorBlock and the ability to bypass YouTube&#039;s detection pop-up for a fast and seamless experience.</p>
                    <div class="meta-line">
                        <span>今日安装 101</span>
                        <span>总安装 44.9万</span>
                        <span>更新 2026-06-16</span>
                                                    <span>版本 13.2.x GA</span>
                                            </div>
                </article>
                                            <article class="script-row">
                    <h2>
                                                    <a class="script-title" href="/script.php?key=405130-%E6%96%87%E6%9C%AC%E9%80%89%E4%B8%AD%E5%A4%8D%E5%88%B6">🔥🔥🔥文本选中复制🔥🔥🔥</a>
                                            </h2>
                    <p class="script-description">解除网站不允许复制的限制，文本选中后点击复制按钮即可复制，主要用于 百度文库 道客巴巴 腾讯文档 豆丁网 无忧考网 学习啦 蓬勃范文 思否社区 力扣 知乎 语雀 等</p>
                    <div class="meta-line">
                        <span>今日安装 88</span>
                        <span>总安装 283.9万</span>
                        <span>更新 2026-01-03 <span class="stale-update">太久没更新</span></span>
                                                    <span>版本 6.2.10</span>
                                            </div>
                </article>
                                            <article class="script-row">
                    <h2>
                                                    <a class="script-title" href="/script.php?key=559462-2026%E6%9C%80%E6%96%B0%E5%8F%AF%E7%94%A8-%E7%99%BE%E5%BA%A6%E7%BD%91%E7%9B%98svip%E9%AB%98%E9%80%9F%E8%A7%A3%E6%9E%90%E7%9B%B4%E9%93%BE%E7%9A%84%E4%B8%8D%E9%99%90%E9%80%9F%E4%B8%8B%E8%BD%BD%E5%8A%A9%E6%89%8B-hcxbaidudownload">2026最新可用-百度网盘SVIP高速解析直链的不限速下载助手 | HcxBaiduDownload</a>
                                            </h2>
                    <p class="script-description">百度网盘文件高速下载工具，自动处理文件重命名，支持小于150M文件快速下载</p>
                    <div class="meta-line">
                        <span>今日安装 88</span>
                        <span>总安装 1万</span>
                        <span>更新 2026-06-01</span>
                                                    <span>版本 2.0.3</span>
                                            </div>
                </article>
                                            <article class="script-row">
                    <h2>
                                                    <a class="script-title" href="/script.php?key=561432-easytube-v5-youtube-ad-skip-sponsorblock-force-4k-hd-downloader">EasyTube V5 — YouTube Ad Skip, SponsorBlock, Force 4K &amp; HD Downloader</a>
                                            </h2>
                    <p class="script-description">Fast YouTube ad blocker and ad skipper with SponsorBlock, automatic sponsor skipping, force 4K playback, HD video download, saved settings and adblock detection bypass. Lightweight and lag-free.</p>
                    <div class="meta-line">
                        <span>今日安装 85</span>
                        <span>总安装 8,459</span>
                        <span>更新 2026-06-15</span>
                                                    <span>版本 5.1.0</span>
                                            </div>
                </article>
                                            <article class="script-row">
                    <h2>
                                                    <a class="script-title" href="/script.php?key=500213-bilibili-video-cdn-switcher">Bilibili Video CDN Switcher</a>
                                            </h2>
                    <p class="script-description">修改哔哩哔哩播放时的所用CDN 加快视频加载 番剧加速 视频加速</p>
                    <div class="meta-line">
                        <span>今日安装 78</span>
                        <span>总安装 9,609</span>
                        <span>更新 2024-07-22 <span class="stale-update">太久没更新</span></span>
                                                    <span>版本 0.1.2</span>
                                            </div>
                </article>
                                            <article class="script-row">
                    <h2>
                                                    <a class="script-title" href="/script.php?key=459541-youtube-adb">youtube-adb</a>
                                            </h2>
                    <p class="script-description">A script to remove YouTube ads, including static ads and video ads, without interfering with the network and ensuring safety.</p>
                    <div class="meta-line">
                        <span>今日安装 72</span>
                        <span>总安装 30.4万</span>
                        <span>更新 2024-11-15 <span class="stale-update">太久没更新</span></span>
                                                    <span>版本 6.21</span>
                                            </div>
                </article>
                                            <article class="script-row">
                    <h2>
                                                    <a class="script-title" href="/script.php?key=30545-html5%E8%A7%86%E9%A2%91%E6%92%AD%E6%94%BE%E5%B7%A5%E5%85%B7">HTML5视频播放工具</a>
                                            </h2>
                    <p class="script-description">视频截图；切换画中画；缓存视频；万能网页全屏；添加快捷键：快进、快退、暂停/播放、音量、下一集、切换(网页)全屏、上下帧、播放速度。支持视频站点：油管、TED、优.土、QQ、B站、西瓜视频、爱奇艺、A站、PPTV、芒果TV、咪咕视频、新浪、微博、网易[娱乐、云课堂、新闻]、搜狐、风行、百度云视频等；直播：twitch、斗鱼、YY、虎牙、龙珠、战旗。可增加自定义站点</p>
                    <div class="meta-line">
                        <span>今日安装 69</span>
                        <span>总安装 128.2万</span>
                        <span>更新 2025-08-06 <span class="stale-update">太久没更新</span></span>
                                                    <span>版本 2.0.2</span>
                                            </div>
                </article>
                                            <article class="script-row">
                    <h2>
                                                    <a class="script-title" href="/script.php?key=579111-%E5%A4%B8%E5%85%8B%E7%BD%91%E7%9B%98%E4%B8%8B%E8%BD%BD%E5%8A%A9%E6%89%8B">夸克网盘下载助手</a>
                                            </h2>
                    <p class="script-description">夸克网盘增强下载助手。支持批量下载、直链导出、aria2/IDM/cURL、下载历史、文件过滤、深色模式、快捷键操作。</p>
                    <div class="meta-line">
                        <span>今日安装 64</span>
                        <span>总安装 2,465</span>
                        <span>更新 2026-05-21</span>
                                                    <span>版本 1.2.0</span>
                                            </div>
                </article>
                                            <article class="script-row">
                    <h2>
                                                    <a class="script-title" href="/script.php?key=413228-bilibili%E8%A7%86%E9%A2%91%E4%B8%8B%E8%BD%BD">bilibili视频下载</a>
                                            </h2>
                    <p class="script-description">支持Web、RPC、Blob、Aria等下载方式；支持下载flv、dash、mp4视频格式；支持下载港区番剧；支持下载字幕弹幕；支持换源播放等功能</p>
                    <div class="meta-line">
                        <span>今日安装 63</span>
                        <span>总安装 53.3万</span>
                        <span>更新 2025-12-23 <span class="stale-update">太久没更新</span></span>
                                                    <span>版本 2.9.2</span>
                                            </div>
                </article>
                                            <article class="script-row">
                    <h2>
                                                    <a class="script-title" href="/script.php?key=525471-telegram-media-downloader-improved">Telegram Media Downloader (Improved)</a>
                                            </h2>
                    <p class="script-description">Download images, GIFs, videos, and voice messages on the Telegram webapp from private channels that disable downloading and restrict saving content</p>
                    <div class="meta-line">
                        <span>今日安装 53</span>
                        <span>总安装 3.2万</span>
                        <span>更新 2025-04-14 <span class="stale-update">太久没更新</span></span>
                                                    <span>版本 1.4</span>
                                            </div>
                </article>
                                            <article class="script-row">
                    <h2>
                                                    <a class="script-title" href="/script.php?key=384538-%E7%8E%A9%E7%9A%84%E5%97%A8-vip%E5%B7%A5%E5%85%B7%E7%AE%B1-%E5%A4%B8%E5%85%8B%E7%BD%91%E7%9B%98%E7%9B%B4%E9%93%BE%E6%89%B9%E9%87%8F%E8%8E%B7%E5%8F%96-%E8%8E%B7%E5%8F%96b%E7%AB%99%E5%B0%81%E9%9D%A2-%E4%B8%8B%E8%BD%BDb%E7%AB%99%E8%A7%86%E9%A2%91%E7%AD%89%E4%BC%97%E5%A4%9A%E5%8A%9F%E8%83%BD%E8%81%9A%E5%90%88-%E9%95%BF%E6%9C%9F%E6%9B%B4%E6%96%B0-%E6%94%BE%E5%BF%83%E4%BD%BF%E7%94%A8">【玩的嗨】VIP工具箱,夸克网盘直链批量获取,获取B站封面,下载B站视频等众多功能聚合 长期更新，放心使用</a>
                                            </h2>
                    <p class="script-description">🔥功能介绍🔥：🎉 1、一站式音乐搜索解决方案；🎉 2、bilibili视频封面获取；🎉 3、bilibili视频下载(已支持分P下载)；🎉 4、夸克网盘直链批量获取；🎉 5、CSDN页面、剪切板清理；🎉 6、页面自动展开(更多网站匹配中,欢迎提交想要支持的网站) 🎉7、YouTube视频下载🎉 8、中间页自动跳转；🎉 9、搜索引擎快速跳转</p>
                    <div class="meta-line">
                        <span>今日安装 52</span>
                        <span>总安装 653.3万</span>
                        <span>更新 2025-10-10 <span class="stale-update">太久没更新</span></span>
                                                    <span>版本 4.9.28</span>
                                            </div>
                </article>
                                            <article class="script-row">
                    <h2>
                                                    <a class="script-title" href="/script.php?key=14178-ac-baidu-%E9%87%8D%E5%AE%9A%E5%90%91%E4%BC%98%E5%8C%96%E7%99%BE%E5%BA%A6%E6%90%9C%E7%8B%97%E8%B0%B7%E6%AD%8C%E5%BF%85%E5%BA%94%E6%90%9C%E7%B4%A2-favicon-%E5%8F%8C%E5%88%97">AC-baidu-重定向优化百度搜狗谷歌必应搜索_favicon_双列</a>
                                            </h2>
                    <p class="script-description">1.繞過百度、搜狗、谷歌、好搜搜索結果中的自己的跳轉鏈接，直接訪問原始網頁-反正都能看懂 2.新增自定义网站拦截功能 3添加Favicon显示 4.页面CSS 5.添加计数 6.开关选择以上功能 7.自动翻页功能</p>
                    <div class="meta-line">
                        <span>今日安装 51</span>
                        <span>总安装 342.8万</span>
                        <span>更新 2026-06-29</span>
                                                    <span>版本 27.20</span>
                                            </div>
                </article>
                                            <article class="script-row">
                    <h2>
                                                    <a class="script-title" href="/script.php?key=435208-github-%E4%B8%AD%E6%96%87%E5%8C%96%E6%8F%92%E4%BB%B6">GitHub 中文化插件</a>
                                            </h2>
                    <p class="script-description">中文化 GitHub 界面的部分菜单及内容。原作者为楼教主(http://www.52cik.com/)。</p>
                    <div class="meta-line">
                        <span>今日安装 51</span>
                        <span>总安装 13万</span>
                        <span>更新 2026-06-25</span>
                                                    <span>版本 1.9.2.4-2026-06-21</span>
                                            </div>
                </article>
                                            <article class="script-row">
                    <h2>
                                                    <a class="script-title" href="/script.php?key=404535-ig-helper">IG小助手</a>
                                            </h2>
                    <p class="script-description">一键下载 Instagram 帖子中的照片和视频，还包括快拍、Reels 和头像。</p>
                    <div class="meta-line">
                        <span>今日安装 50</span>
                        <span>总安装 5万</span>
                        <span>更新 2026-07-17</span>
                                                    <span>版本 4.0.4</span>
                                            </div>
                </article>
                                            <article class="script-row">
                    <h2>
                                                    <a class="script-title" href="/script.php?key=412245-github-enhancement-high-speed-download">Github 增强 - 高速下载</a>
                                            </h2>
                    <p class="script-description">高速下载 Git Clone/SSH、Release、Raw、Code(ZIP) 等文件 (公益加速)、项目列表单文件快捷下载 (☁)</p>
                    <div class="meta-line">
                        <span>今日安装 49</span>
                        <span>总安装 89.7万</span>
                        <span>更新 2026-05-28</span>
                                                    <span>版本 2.6.38</span>
                                            </div>
                </article>
                                            <article class="script-row">
                    <h2>
                                                    <a class="script-title" href="/script.php?key=521434-youtube-%E8%A7%86%E9%A2%91%E4%B8%8B%E8%BD%BD%E5%8A%A9%E6%89%8B-%E5%A4%9A%E7%A7%8D%E6%B8%85%E6%99%B0%E5%BA%A6hd-2k-4k-video-audio">YouTube 视频下载助手｜多种清晰度HD/2K/4K🔥｜Video&amp;Audio 📥</a>
                                            </h2>
                    <p class="script-description">YouTube视频下载神器，支持1080P/2K高清视频下载，支持字幕下载，支持视频/音频分离下载，支持短视频下载，完全免费无广告</p>
                    <div class="meta-line">
                        <span>今日安装 49</span>
                        <span>总安装 4.2万</span>
                        <span>更新 2026-03-08 <span class="stale-update">太久没更新</span></span>
                                                    <span>版本 1.5.1</span>
                                            </div>
                </article>
                                            <article class="script-row">
                    <h2>
                                                    <a class="script-title" href="/script.php?key=459137-1-chess-assistant-a-c-a-s-advanced-chess-assistance-system">🏆 [#1 Chess Assistant] A.C.A.S (Advanced Chess Assistance System)</a>
                                            </h2>
                    <p class="script-description">Enhance your chess performance with a cutting-edge real-time move analysis and strategy assistance system</p>
                    <div class="meta-line">
                        <span>今日安装 48</span>
                        <span>总安装 6.1万</span>
                        <span>更新 2026-06-28</span>
                                                    <span>版本 2.4.4</span>
                                            </div>
                </article>
                                            <article class="script-row">
                    <h2>
                                                    <a class="script-title" href="/script.php?key=477900-telegram-web-media-downloader-save-restricted-photos-videos-batch-copy-text">Telegram Web Media Downloader — Save Restricted Photos &amp; Videos (Batch) + Copy Text</a>
                                            </h2>
                    <p class="script-description">Download photos and videos from Telegram Web, one by one or in batches — even in restricted &quot;no-forwards&quot; chats. Also re-enables copying text from protected messages.</p>
                    <div class="meta-line">
                        <span>今日安装 48</span>
                        <span>总安装 2.5万</span>
                        <span>更新 2026-06-06</span>
                                                    <span>版本 1.0</span>
                                            </div>
                </article>
                                            <article class="script-row">
                    <h2>
                                                    <a class="script-title" href="/script.php?key=381682-%E9%9F%B3%E8%A7%86%E9%A2%91%E5%A2%9E%E5%BC%BA%E8%84%9A%E6%9C%AC-%E6%97%A0%E6%9E%81%E8%B0%83%E9%80%9F-%E5%80%8D%E9%80%9F%E5%BF%AB%E5%AD%A6-%E5%BF%AB%E4%B9%90%E5%88%B7%E5%89%A7-%E8%A7%86%E9%A2%91%E4%B8%8B%E8%BD%BD-%E7%94%BB%E9%9D%A2%E6%88%AA%E5%9B%BE%E7%AD%89-%E9%80%82%E7%94%A8%E5%A4%A7%E9%83%A8%E5%88%86%E7%BD%91%E7%AB%99">音视频增强脚本：无极调速|倍速快学|快乐刷剧|视频下载|画面截图等「适用大部分网站」</a>
                                            </h2>
                    <p class="script-description">视频增强脚本，支持所有H5音视频网站，例如：B站、抖音、腾讯视频、优酷、爱奇艺、西瓜视频、油管（YouTube）、微博视频、知乎视频、搜狐视频、网易公开课、百度网盘、阿里云盘、ted、instagram、twitter等。全程快捷键控制，支持：倍速播放/加速播放、视频画面截图、画中画、网页全屏、调节亮度、饱和度、对比度、自定义配置功能增强等功能，为你提供愉悦的在线视频播放体验。还有视频广告快进、在线教程/教育视频倍速快学、视频文件下载等能力</p>
                    <div class="meta-line">
                        <span>今日安装 47</span>
                        <span>总安装 128.4万</span>
                        <span>更新 2026-03-23 <span class="stale-update">太久没更新</span></span>
                                                    <span>版本 4.3.5</span>
                                            </div>
                </article>
                                            <article class="script-row">
                    <h2>
                                                    <a class="script-title" href="/script.php?key=438684-pagetual">东方永页机</a>
                                            </h2>
                    <p class="script-description">终极自动翻页 - 加载并拼接下一分页内容至当前页尾，智能适配任意网页</p>
                    <div class="meta-line">
                        <span>今日安装 47</span>
                        <span>总安装 46.1万</span>
                        <span>更新 2026-06-08</span>
                                                    <span>版本 1.9.37.132</span>
                                            </div>
                </article>
                                            <article class="script-row">
                    <h2>
                                                    <a class="script-title" href="/script.php?key=23840-greasyfork-search-with-sleazyfork-results-include">大人的Greasyfork</a>
                                            </h2>
                    <p class="script-description">在Greasyfork的搜索结果中添加Sleazyfork上的成人脚本，增加评分与版本号，并在访问匿名不可用脚本时跳转至Sleazyfork</p>
                    <div class="meta-line">
                        <span>今日安装 45</span>
                        <span>总安装 90.7万</span>
                        <span>更新 2023-06-09 <span class="stale-update">太久没更新</span></span>
                                                    <span>版本 1.6.6</span>
                                            </div>
                </article>
                                            <article class="script-row">
                    <h2>
                                                    <a class="script-title" href="/script.php?key=587264-pubg-202607-%E7%A9%BA%E6%8A%95%E7%83%AD%E7%82%B9%E5%8A%9F%E8%83%BD%E8%8F%9C%E5%8D%95">PUBG 202607 空投热点功能菜单</a>
                                            </h2>
                    <p class="script-description">为PUBG2026.7网页小活动提供实用功能</p>
                    <div class="meta-line">
                        <span>今日安装 45</span>
                        <span>总安装 45</span>
                        <span>更新 2026-07-17</span>
                                                    <span>版本 1.0.2</span>
                                            </div>
                </article>
                                            <article class="script-row">
                    <h2>
                                                    <a class="script-title" href="/script.php?key=571423-twitter-x-media-downloader">Twitter/X 媒体下载器</a>
                                            </h2>
                    <p class="script-description">一键下载 Twitter/X 图片和视频，支持自定义文件名和下载历史记录。</p>
                    <div class="meta-line">
                        <span>今日安装 44</span>
                        <span>总安装 3,332</span>
                        <span>更新 2026-05-22</span>
                                                    <span>版本 0.3.1</span>
                                            </div>
                </article>
                                            <article class="script-row">
                    <h2>
                                                    <a class="script-title" href="/script.php?key=582026-bilibili-accelerator">Bilibili Accelerator - B站海外播放加速</a>
                                            </h2>
                    <p class="script-description">自动改写 B 站慢 CDN 播放地址，缓解海外用户看冷门视频时的卡顿。</p>
                    <div class="meta-line">
                        <span>今日安装 42</span>
                        <span>总安装 543</span>
                        <span>更新 2026-07-15</span>
                                                    <span>版本 0.3.0</span>
                                            </div>
                </article>
                                            <article class="script-row">
                    <h2>
                                                    <a class="script-title" href="/script.php?key=378351-csdngreener-csdn%E5%B9%BF%E5%91%8A%E5%AE%8C%E5%85%A8%E8%BF%87%E6%BB%A4-%E5%85%8D%E7%99%BB%E5%BD%95-%E4%B8%AA%E6%80%A7%E5%8C%96%E6%8E%92%E7%89%88-%E6%9C%80%E5%BC%BA%E8%80%81%E7%89%8C%E8%84%9A%E6%9C%AC-%E6%8C%81%E7%BB%AD%E6%9B%B4%E6%96%B0">「CSDNGreener」🍃CSDN广告完全过滤|免登录|个性化排版|最强老牌脚本|持续更新</a>
                                            </h2>
                    <p class="script-description">⚡️全新5.0版本！模块化重构+AI智能模式+HD版式⚡️|🤖智能自适应布局，完美适配各种分辨率|🖥HD高分辨率优化，1920px+屏幕体验更佳|⚙️实时预览配置，修改立即生效|🕶无需登录CSDN，获得比会员更佳的体验|📠免登录复制|🌵全面净化广告|🔗防外链重定向|📈沉浸阅读体验</p>
                    <div class="meta-line">
                        <span>今日安装 41</span>
                        <span>总安装 175.7万</span>
                        <span>更新 2026-05-09 <span class="stale-update">太久没更新</span></span>
                                                    <span>版本 5.0.4</span>
                                            </div>
                </article>
                                            <article class="script-row">
                    <h2>
                                                    <a class="script-title" href="/script.php?key=431573-youtube-cpu-tamer-by-animationframe">YouTube CPU Tamer by AnimationFrame</a>
                                            </h2>
                    <p class="script-description">减少YouTube影片所致的能源消耗</p>
                    <div class="meta-line">
                        <span>今日安装 40</span>
                        <span>总安装 5.6万</span>
                        <span>更新 2025-02-24 <span class="stale-update">太久没更新</span></span>
                                                    <span>版本 2025.02.24.0</span>
                                            </div>
                </article>
                                            <article class="script-row">
                    <h2>
                                                    <a class="script-title" href="/script.php?key=523483-scribd-downloader-button">Scribd下载按钮（打开下载链接）</a>
                                            </h2>
                    <p class="script-description">在Scribd页面添加一个按钮，打开一个修改过的下载链接，方便访问。</p>
                    <div class="meta-line">
                        <span>今日安装 40</span>
                        <span>总安装 9,355</span>
                        <span>更新 2025-01-11 <span class="stale-update">太久没更新</span></span>
                                                    <span>版本 1.0.1</span>
                                            </div>
                </article>
                                            <article class="script-row">
                    <h2>
                                                    <a class="script-title" href="/script.php?key=561041-duolingo-duohacker">多邻国 DuoHacker</a>
                                            </h2>
                    <p class="script-description">最强 Duolingo 辅助工具 - 自动刷 XP、宝石、连胜，免费解锁 Duolingo Max。</p>
                    <div class="meta-line">
                        <span>今日安装 40</span>
                        <span>总安装 5,068</span>
                        <span>更新 2026-07-13</span>
                                                    <span>版本 2026.07.13</span>
                                            </div>
                </article>
                                            <article class="script-row">
                    <h2>
                                                    <a class="script-title" href="/script.php?key=572651-cheatguessr-universal-geoguessr-openguessr-worldguessr-freeguessr-geoduels-geotastic">CheatGuessr Universal｜GeoGuessr｜OpenGuessr｜WorldGuessr｜FreeGuessr｜GeoDuels | Geotastic</a>
                                            </h2>
                    <p class="script-description">隐蔽式 GeoGuessr 辅助器｜按 Tab 打开设置菜单｜地图标点｜发送 Discord｜在 Google 地图中打开当前位置</p>
                    <div class="meta-line">
                        <span>今日安装 40</span>
                        <span>总安装 7,351</span>
                        <span>更新 2026-07-13</span>
                                                    <span>版本 12.7</span>
                                            </div>
                </article>
                                            <article class="script-row">
                    <h2>
                                                    <a class="script-title" href="/script.php?key=583582-linkswift">LinkSwift</a>
                                            </h2>
                    <p class="script-description">(｡&gt;ᴗ•)✧《也许同类型中最好用？》系列 - 一个基于 JavaScript 的网盘文件下载地址获取工具✨，基于【网盘直链下载助手】修改 | 支持 百度网盘 / 阿里云盘 / 中国移动云盘 / 天翼云盘 / 迅雷云盘 / 夸克网盘 / UC网盘 / 123云盘 八大网盘 | 开源・自用・去广 | 改界面・添功能・修Bug | 既超越原版，亦是同类中最好用版本！👋</p>
                    <div class="meta-line">
                        <span>今日安装 39</span>
                        <span>总安装 947</span>
                        <span>更新 2026-06-20</span>
                                                    <span>版本 1.1.3</span>
                                            </div>
                </article>
                                            <article class="script-row">
                    <h2>
                                                    <a class="script-title" href="/script.php?key=406070-%E5%B0%8F%E8%AF%B4%E4%B8%8B%E8%BD%BD%E5%99%A8">小说下载器</a>
                                            </h2>
                    <p class="script-description">一个可扩展的通用型小说下载器。</p>
                    <div class="meta-line">
                        <span>今日安装 38</span>
                        <span>总安装 12.5万</span>
                        <span>更新 2026-06-10</span>
                                                    <span>版本 5.2.1260</span>
                                            </div>
                </article>
                                            <article class="script-row">
                    <h2>
                                                    <a class="script-title" href="/script.php?key=586983-quark-web-cloud-drive-direct-link-extractor">夸克网盘网页版直链提取器</a>
                                            </h2>
                    <p class="script-description">在夸克网盘网页版中批量提取并复制文件的直接下载链接，提供外部下载器（Gopeed/IDM）专用UA与Cookie一键复制。</p>
                    <div class="meta-line">
                        <span>今日安装 37</span>
                        <span>总安装 127</span>
                        <span>更新 2026-07-15</span>
                                                    <span>版本 1.0.3</span>
                                            </div>
                </article>
                                            <article class="script-row">
                    <h2>
                                                    <a class="script-title" href="/script.php?key=374794-lift-web-restrictions-io-game-mods-moomoo-io-krunker-io-ad-link-bypasser-adblock-more">解除网络限制：.io游戏模型 、广告链接绕过器、广告拦截器，以及更多!</a>
                                            </h2>
                    <p class="script-description">一个巨大的用户脚本，可以修改数百个网站，为网络添加修改、黑客、新功能和生活质量! (测试版）值得注意的功能：自动重定向和绕过，一个全功能的MooMoo.io黑客，谷歌教室的黑暗模式，大量删除discord信息，删除百度上的广告，禁用谷歌分析，Facebook广告拦截器！（测试版）。</p>
                    <div class="meta-line">
                        <span>今日安装 36</span>
                        <span>总安装 78.5万</span>
                        <span>更新 2024-03-01 <span class="stale-update">太久没更新</span></span>
                                                    <span>版本 13</span>
                                            </div>
                </article>
                                            <article class="script-row">
                    <h2>
                                                    <a class="script-title" href="/script.php?key=460680-youtube-tools-all-in-one-local-download-mp3-mp4-higt-quality-return-dislikes-and-more">Youtube 工具 多合一本地下載 MP4、MP3</a>
                                            </h2>
                    <p class="script-description">Youtube 工具 多合一本地下載 mp4、MP3</p>
                    <div class="meta-line">
                        <span>今日安装 34</span>
                        <span>总安装 19.3万</span>
                        <span>更新 2026-02-06 <span class="stale-update">太久没更新</span></span>
                                                    <span>版本 2.4.3.2</span>
                                            </div>
                </article>
                                            <article class="script-row">
                    <h2>
                                                    <a class="script-title" href="/script.php?key=558825-%E5%A4%B8%E5%85%8B%E7%BD%91%E7%9B%98%E7%9B%B4%E9%93%BE%E4%B8%8B%E8%BD%BD%E5%8A%A9%E6%89%8B">夸克网盘直链下载助手</a>
                                            </h2>
                    <p class="script-description">解除夸克网盘分享页面的下载限制。支持批量导出直链，支持IDM/NDM，修复了 UA 和 Cookie 冲突问题。</p>
                    <div class="meta-line">
                        <span>今日安装 33</span>
                        <span>总安装 1.4万</span>
                        <span>更新 2025-12-21 <span class="stale-update">太久没更新</span></span>
                                                    <span>版本 1.6.6</span>
                                            </div>
                </article>
                                            <article class="script-row">
                    <h2>
                                                    <a class="script-title" href="/script.php?key=24204-picviewer-ce">Picviewer CE+</a>
                                            </h2>
                    <p class="script-description">在线看图工具，支持图片翻转、旋转、缩放、弹出大图、批量保存</p>
                    <div class="meta-line">
                        <span>今日安装 32</span>
                        <span>总安装 30.7万</span>
                        <span>更新 2026-02-06 <span class="stale-update">太久没更新</span></span>
                                                    <span>版本 2026.2.6.1</span>
                                            </div>
                </article>
                                            <article class="script-row">
                    <h2>
                                                    <a class="script-title" href="/script.php?key=406535-instagram-download-button">Instagram 下载器</a>
                                            </h2>
                    <p class="script-description">在Instagram页面加入下载按钮与开启按钮，透过这些按钮可以下载或开启大头贴与贴文、限时动态、Highlight中的照片或影片</p>
                    <div class="meta-line">
                        <span>今日安装 32</span>
                        <span>总安装 16.7万</span>
                        <span>更新 2024-03-10 <span class="stale-update">太久没更新</span></span>
                                                    <span>版本 1.17.18</span>
                                            </div>
                </article>
                                            <article class="script-row">
                    <h2>
                                                    <a class="script-title" href="/script.php?key=431044-fsu-eafc-fut-web-%E5%A2%9E%E5%BC%BA%E5%99%A8">【FSU】EAFC FUT WEB 增强器</a>
                                            </h2>
                    <p class="script-description">EAFCFUT模式SBC任务便捷操作增强器👍👍👍，模拟开包、额外信息展示、近期低价自动查询、一键挂出球员、跳转FUTBIN、快捷搜索、拍卖行优化等等...👍👍👍</p>
                    <div class="meta-line">
                        <span>今日安装 32</span>
                        <span>总安装 15.3万</span>
                        <span>更新 2026-05-11 <span class="stale-update">太久没更新</span></span>
                                                    <span>版本 26.09</span>
                                            </div>
                </article>
                                            <article class="script-row">
                    <h2>
                                                    <a class="script-title" href="/script.php?key=580500-%E5%B8%B8%E7%9C%8Bvip%E8%A7%86%E9%A2%91%E5%85%A8%E7%BD%91%E8%A7%A3%E6%9E%90-beta%E7%89%88">常看VIP视频全网解析 (Beta版)</a>
                                            </h2>
                    <p class="script-description">💎VIP视频解析 | 🎬爱奇艺解析 | 🔍腾讯VIP去广 | 📺优酷独播解锁 | ⚡芒果TV大会员 | 🎥B站番剧解析 | 🔗搜狐视频直连 | ✦乐视超清播放 | ◆PPTV聚力解析 | ●咪咕体育直播 | ★西瓜VIP解锁 | 🔍抖音短剧解析 | 🎬快手短视频解析 | 📺1905电影网 | ⚡AcFun弹幕解析 | 🔗土豆/风行/暴风兼容 | ✦全网影视通解 | ◆4K蓝光画质 | ●HDR杜比音效 | ★智能线路优选 | 💎免登录免费看 | 🎞️热播剧/最新电影/独家综艺/国漫日番 | ⚡极速评估 | 🔄智能缓存 | 🚀DNS预解析 | 🚀24并发加速</p>
                    <div class="meta-line">
                        <span>今日安装 32</span>
                        <span>总安装 1,070</span>
                        <span>更新 2026-07-13</span>
                                                    <span>版本 2.1.9</span>
                                            </div>
                </article>
                                            <article class="script-row">
                    <h2>
                                                    <a class="script-title" href="/script.php?key=419081-zhihu-enhancement">知乎增强</a>
                                            </h2>
                    <p class="script-description">移除登录弹窗、屏蔽指定类别（视频、盐选、文章、想法、关注[赞同/关注了XX]等）、屏蔽低赞/低评、屏蔽用户、屏蔽关键词、默认收起回答、快捷收起回答/评论（左键两侧）、快捷回到顶部（右键两侧）、区分问题文章、移除高亮链接、净化搜索热门、净化标题消息、展开问题描述、显示问题作者、默认高清原图（无水印）、置顶显示时间、完整问题时间、直达问题按钮、默认站外直链...</p>
                    <div class="meta-line">
                        <span>今日安装 31</span>
                        <span>总安装 76.3万</span>
                        <span>更新 2026-05-21</span>
                                                    <span>版本 2.3.29</span>
                                            </div>
                </article>
                                            <article class="script-row">
                    <h2>
                                                    <a class="script-title" href="/script.php?key=579384-linkswift%E5%A2%9E%E5%BC%BA">LinkSwift增强</a>
                                            </h2>
                    <p class="script-description">基于【LinkSwift】修改 | 支持 百度网盘 / 阿里云盘 / 中国移动云盘 / 天翼云盘 / 迅雷云盘 / 夸克网盘 / UC网盘 / 123云盘 八大网盘 | 改界面・添功能・修Bug | 相对原版增加了一些我认为有用的功能</p>
                    <div class="meta-line">
                        <span>今日安装 29</span>
                        <span>总安装 1,680</span>
                        <span>更新 2026-06-07</span>
                                                    <span>版本 1.1.8</span>
                                            </div>
                </article>
                                            <article class="script-row">
                    <h2>
                                                    <a class="script-title" href="/script.php?key=562938-greasyfork-premium">GreasyFork 高级版</a>
                                            </h2>
                    <p class="script-description">GreasyFork 和 SleazyFork 高级增强：现代化界面、一键收藏、直接安装按钮、脚本详细预览、增强编辑工具栏、浅色/深色主题、优化导航等更多功能。</p>
                    <div class="meta-line">
                        <span>今日安装 28</span>
                        <span>总安装 1,203</span>
                        <span>更新 2026-07-01</span>
                                                    <span>版本 1.2.1</span>
                                            </div>
                </article>
                                            <article class="script-row">
                    <h2>
                                                    <a class="script-title" href="/script.php?key=28497-%E7%BD%91%E9%A1%B5%E9%99%90%E5%88%B6%E8%A7%A3%E9%99%A4-%E6%94%B9">网页限制解除(改)</a>
                                            </h2>
                    <p class="script-description">通杀大部分网站,可以解除禁止复制、剪切、选择文本、右键菜单的限制。原作者cat73,因为和搜索跳转脚本冲突,遂进行了改动。</p>
                    <div class="meta-line">
                        <span>今日安装 27</span>
                        <span>总安装 223万</span>
                        <span>更新 2022-12-13 <span class="stale-update">太久没更新</span></span>
                                                    <span>版本 4.4.8</span>
                                            </div>
                </article>
                                            <article class="script-row">
                    <h2>
                                                    <a class="script-title" href="/script.php?key=407485-github-internationalization">GitHub汉化插件</a>
                                            </h2>
                    <p class="script-description">GitHub汉化插件，包含人机翻译</p>
                    <div class="meta-line">
                        <span>今日安装 27</span>
                        <span>总安装 14.4万</span>
                        <span>更新 2026-06-16</span>
                                                    <span>版本 0.32</span>
                                            </div>
                </article>
                                            <article class="script-row">
                    <h2>
                                                    <a class="script-title" href="/script.php?key=434956-%E6%8A%96%E9%9F%B3%E7%BD%91%E9%A1%B5%E7%89%88%E4%BC%98%E5%8C%96">抖音网页版优化</a>
                                            </h2>
                    <p class="script-description">抖音网页版推荐、直播优化，网页全屏，全黑，自动按浏览器窗口调整大小</p>
                    <div class="meta-line">
                        <span>今日安装 27</span>
                        <span>总安装 3万</span>
                        <span>更新 2026-07-03</span>
                                                    <span>版本 1.14.21</span>
                                            </div>
                </article>
                                            <article class="script-row">
                    <h2>
                                                    <a class="script-title" href="/script.php?key=440871-%E9%AA%9A%E6%89%B0%E6%8B%A6%E6%88%AA">骚扰拦截</a>
                                            </h2>
                    <p class="script-description">手机、电脑全平台通用:自动拦截或删除`下载弹窗`、`悬浮按钮`等影响用户体验的元素;长期维护:CSDN、简书、知乎、知乎专栏、百度搜索、百家号、百度贴吧、百度文库、百度新闻、新浪新闻、腾讯视频、优酷视频、爱奇艺、好看视频、哔哩哔哩、B站专栏、B站笔记、西瓜视频、抖音、丁香园、健康界、微博、新浪财经、东方财富网、电子发烧友、人民网、新京报、观察者网、澎湃新闻、凤凰新闻、网易新闻、今日头条、东方资讯、虎嗅、虎扑、豆瓣、中关村在线、太平洋电脑、太平洋汽车网、汽车之家、太平洋汽车网、taptap、it之家、360doc、开源中国、segmentfault、W3CSchool、阿里云开发者社区、腾讯云开发者社区、华为云开发者社区、36氪、雪球、天眼查、站酷、小红书、中国知网、装备前线、必应搜索、什么值得买、夸克网盘</p>
                    <div class="meta-line">
                        <span>今日安装 27</span>
                        <span>总安装 27.5万</span>
                        <span>更新 2026-06-26</span>
                                                    <span>版本 1.5.9</span>
                                            </div>
                </article>
                                            <article class="script-row">
                    <h2>
                                                    <a class="script-title" href="/script.php?key=470154-%E5%AA%92%E4%BD%93%E8%B5%84%E6%BA%90%E5%97%85%E6%8E%A2%E5%8F%8A%E4%B8%8B%E8%BD%BD-%E6%94%AF%E6%8C%81%E4%B8%8B%E8%BD%BDm3u8%E5%92%8Cmp4%E8%A7%86%E9%A2%91%E5%92%8C%E9%9F%B3%E9%A2%91">媒体资源嗅探及下载(支持下载m3u8和mp4视频和音频)</a>
                                            </h2>
                    <p class="script-description">功能包含：1、自动嗅探页面上的视频、音频资源，列出链接，并提供播放、复制和下载功能（提供 mp3、mp4 和 m3u8 资源下载）；2、录屏；3、解除页面复制限制。</p>
                    <div class="meta-line">
                        <span>今日安装 27</span>
                        <span>总安装 14.3万</span>
                        <span>更新 2025-07-24 <span class="stale-update">太久没更新</span></span>
                                                    <span>版本 1.985</span>
                                            </div>
                </article>
                                            <article class="script-row">
                    <h2>
                                                    <a class="script-title" href="/script.php?key=483464-new-format-baidunetdisk-fake-quick-save-%E6%96%B0%E5%9E%8B%E6%A0%BC%E5%BC%8F-%E7%99%BE%E5%BA%A6%E7%BD%91%E7%9B%98%E7%A7%92%E4%BC%A0-%E5%81%BD-%E9%93%BE%E6%8E%A5%E6%8F%90%E5%8F%96-%E8%BD%AC%E5%AD%98">（New Format）BaiduNetDisk Fake Quick Save （新型格式）百度网盘秒传(偽)链接提取 转存</a>
                                            </h2>
                    <p class="script-description">BaiduPan for generating links and saving files. 百度網盤轉存(偽)</p>
                    <div class="meta-line">
                        <span>今日安装 26</span>
                        <span>总安装 5.6万</span>
                        <span>更新 2024-01-02 <span class="stale-update">太久没更新</span></span>
                                                    <span>版本 0.1</span>
                                            </div>
                </article>
                                            <article class="script-row">
                    <h2>
                                                    <a class="script-title" href="/script.php?key=486211-%E6%9C%80%E5%BC%BA%E6%97%A0%E5%A5%97%E8%B7%AF%E8%84%9A%E6%9C%AC-%E4%BD%A0%E8%83%BD%E7%9C%8B%E8%A7%81%E5%A4%9A%E5%B0%91%E6%88%91%E8%83%BD%E4%B8%8B%E8%BD%BD%E5%A4%9A%E5%B0%91-%E4%B8%8B%E8%BD%BD%E5%85%AC%E5%BC%80%E5%85%8D%E8%B4%B9%E7%9A%84ppt-pdf-doc-txt%E7%AD%89%E6%96%87%E4%BB%B6">【最强无套路脚本】你能看见多少我能下载多少&amp;下载公开免费的PPT、PDF、DOC、TXT等文件</a>
                                            </h2>
                    <p class="script-description">百度|原创力|人人|360文库|豆丁|豆丁建筑|道客|MBA智库|得力|七彩学科|金锄头|爱问|蚂蚁|读根网|搜弘|微传网|淘豆网|GB|JJG|行业标准|轻竹办公|自然标准|交通标准|飞书|江苏计量|水利部|招投标|能源标准|认证认可标准|腾讯文档|绿色建站|电网|夸克文库等公开免费文档下载</p>
                    <div class="meta-line">
                        <span>今日安装 26</span>
                        <span>总安装 25.3万</span>
                        <span>更新 2025-12-12 <span class="stale-update">太久没更新</span></span>
                                                    <span>版本 7.7</span>
                                            </div>
                </article>
                                            <article class="script-row">
                    <h2>
                                                    <a class="script-title" href="/script.php?key=528890-x-twitter-%E3%83%A1%E3%83%87%E3%82%A3%E3%82%A2%E4%B8%80%E6%8B%AC%E3%83%80%E3%82%A6%E3%83%B3%E3%83%AD%E3%83%BC%E3%83%80%E3%83%BC-iphone-android-%E5%AF%BE%E5%BF%9C">X/Twitter メディア一括ダウンローダー（iPhone/Android 対応)</a>
                                            </h2>
                    <p class="script-description">X/Twitterの画像、動画、GIFをワンクリックでダウンロードします。標準ではユーザーIDとポストIDで保存されますが、追加される設定画面からファイル名や日時フォーマットを自由に変更可能です。iPhoneやAndroid環境でもZIP集約により複数メディアを一括ダウンロードできます。ダウンロード履歴のローカル保存に加え、オプションでXのブックマーク機能を利用したオンライン同期にも対応しています。</p>
                    <div class="meta-line">
                        <span>今日安装 26</span>
                        <span>总安装 1万</span>
                        <span>更新 2026-07-17</span>
                                                    <span>版本 1.5.2</span>
                                            </div>
                </article>
                                            <article class="script-row">
                    <h2>
                                                    <a class="script-title" href="/script.php?key=578403-kour-io-cheat">Kour.io 辅助</a>
                                            </h2>
                    <p class="script-description">终极 Kour.io 体验。功能：自动瞄准、透视 (ESP)、即时击杀、狂暴陀螺 (Spinbot)、连跳 (Bhop)。</p>
                    <div class="meta-line">
                        <span>今日安装 26</span>
                        <span>总安装 1,894</span>
                        <span>更新 2026-05-16 <span class="stale-update">太久没更新</span></span>
                                                    <span>版本 1.0</span>
                                            </div>
                </article>
                                            <article class="script-row">
                    <h2>
                                                    <a class="script-title" href="/script.php?key=527498-custom-cdn-of-bilibili-ccb-%E4%BF%AE%E6%94%B9%E5%93%94%E5%93%A9%E5%93%94%E5%93%A9%E7%9A%84%E7%BD%91%E9%A1%B5%E8%A7%86%E9%A2%91-%E7%9B%B4%E6%92%AD-%E7%95%AA%E5%89%A7%E7%9A%84%E6%92%AD%E6%94%BE%E6%BA%90">Custom CDN of Bilibili (CCB) - 修改哔哩哔哩的网页视频、直播、番剧的播放源</a>
                                            </h2>
                    <p class="script-description">Custom CDN of Bilibili (CCB)</p>
                    <div class="meta-line">
                        <span>今日安装 24</span>
                        <span>总安装 2,736</span>
                        <span>更新 2026-02-04 <span class="stale-update">太久没更新</span></span>
                                                    <span>版本 2.0.2</span>
                                            </div>
                </article>
                                            <article class="script-row">
                    <h2>
                                                    <a class="script-title" href="/script.php?key=571507-%E6%99%BA%E8%B0%B1-glm-coding-%E7%89%B9%E6%83%A0%E8%AE%A2%E8%B4%AD%E6%8A%A2%E8%B4%AD%E5%8A%A9%E6%89%8B">智谱 GLM Coding 特惠订购抢购助手</a>
                                            </h2>
                    <p class="script-description">用于在前端代码中去除按钮的disabled属性，使其在界面上显示为可点击状态。这仅影响前端表现，不改变后端逻辑(脚本只是辅助，重点是教程)。新增 DOM 渲染置灰。邀请码新购，下单立减5%金额 https://www.bigmodel.cn/glm-coding?ic=EVDHUUYDNB</p>
                    <div class="meta-line">
                        <span>今日安装 24</span>
                        <span>总安装 6,125</span>
                        <span>更新 2026-06-15</span>
                                                    <span>版本 6.6.7</span>
                                            </div>
                </article>
                                            <article class="script-row">
                    <h2>
                                                    <a class="script-title" href="/script.php?key=406849-vip-%E8%A7%86%E9%A2%91%E8%A7%A3%E6%9E%90">VIP 视频解析</a>
                                            </h2>
                    <p class="script-description">支持腾讯视频、爱奇艺、优酷、土豆、芒果TV、搜狐视频、乐视视频、PPTV、风行、华数TV、哔哩哔哩等，支持多个解析接口切换，支持视频自由选集，自动解析视频，支持自定义拖拽位置，支持视频广告跳过，支持页内页外解析，支持 Tampermonkey、Violentmonkey、Greasemonkey</p>
                    <div class="meta-line">
                        <span>今日安装 23</span>
                        <span>总安装 55.7万</span>
                        <span>更新 2024-01-23 <span class="stale-update">太久没更新</span></span>
                                                    <span>版本 3.2.9</span>
                                            </div>
                </article>
                                            <article class="script-row">
                    <h2>
                                                    <a class="script-title" href="/script.php?key=521497-chatgpt-infinity">ChatGPT 无限 ∞</a>
                                            </h2>
                    <p class="script-description">从无所不知的 ChatGPT 生成无穷无尽的答案 (用任何语言!)</p>
                    <div class="meta-line">
                        <span>今日安装 23</span>
                        <span>总安装 8,891</span>
                        <span>更新 2024-12-22 <span class="stale-update">太久没更新</span></span>
                                                    <span>版本 2024.12.21.12</span>
                                            </div>
                </article>
                                            <article class="script-row">
                    <h2>
                                                    <a class="script-title" href="/script.php?key=537017-youtube">YouTube +</a>
                                            </h2>
                    <p class="script-description">标签视图 YouTube、下载及其他功能 ↴</p>
                    <div class="meta-line">
                        <span>今日安装 23</span>
                        <span>总安装 6,347</span>
                        <span>更新 2026-07-01</span>
                                                    <span>版本 2.5.2</span>
                                            </div>
                </article>
                                            <article class="script-row">
                    <h2>
                                                    <a class="script-title" href="/script.php?key=574296-%E4%BA%91%E7%9B%98%E7%A7%92%E4%BC%A0%E5%B7%A5%E5%85%B7-%E7%99%BE%E5%BA%A6-%E5%A4%B8%E5%85%8B-%E5%A4%A9%E7%BF%BC-123-%E5%85%89%E9%B8%AD">云盘秒传工具（百度/夸克/天翼/123/光鸭）</a>
                                            </h2>
                    <p class="script-description">云盘秒传工具支持百度/夸克/天翼/123/光鸭</p>
                    <div class="meta-line">
                        <span>今日安装 23</span>
                        <span>总安装 3,330</span>
                        <span>更新 2026-04-17 <span class="stale-update">太久没更新</span></span>
                                                    <span>版本 2026.04.16</span>
                                            </div>
                </article>
                                            <article class="script-row">
                    <h2>
                                                    <a class="script-title" href="/script.php?key=422818-%E7%BD%91%E7%9B%98%E7%9B%B4%E9%93%BE%E4%B8%8B%E8%BD%BD%E5%8A%A9%E6%89%8B-%E6%94%B9">网盘直链下载助手（改）</a>
                                            </h2>
                    <p class="script-description">基于【网盘直链下载助手】改，原作者：https://www.baiduyun.wiki/，个人使用，去掉了一些广告之类的东西</p>
                    <div class="meta-line">
                        <span>今日安装 22</span>
                        <span>总安装 5.4万</span>
                        <span>更新 2023-11-24 <span class="stale-update">太久没更新</span></span>
                                                    <span>版本 4.4.1</span>
                                            </div>
                </article>
                                            <article class="script-row">
                    <h2>
                                                    <a class="script-title" href="/script.php?key=456055-chatgpt-exporter">ChatGPT Exporter</a>
                                            </h2>
                    <p class="script-description">一键导出 ChatGPT 对话，轻松备份与分享</p>
                    <div class="meta-line">
                        <span>今日安装 22</span>
                        <span>总安装 2.4万</span>
                        <span>更新 2026-07-05</span>
                                                    <span>版本 2.32.3</span>
                                            </div>
                </article>
                                            <article class="script-row">
                    <h2>
                                                    <a class="script-title" href="/script.php?key=473972-youtube-js-engine-tamer">YouTube JS Engine Tamer</a>
                                            </h2>
                    <p class="script-description">修改 YouTube 的 JS 引擎以提升性能</p>
                    <div class="meta-line">
                        <span>今日安装 22</span>
                        <span>总安装 1.8万</span>
                        <span>更新 2026-05-11 <span class="stale-update">太久没更新</span></span>
                                                    <span>版本 0.42.24</span>
                                            </div>
                </article>
                                            <article class="script-row">
                    <h2>
                                                    <a class="script-title" href="/script.php?key=570993-pikpak-%E5%A2%9E%E5%BC%BA%E5%A4%A7%E5%B8%88">PikPak 增强大师</a>
                                            </h2>
                    <p class="script-description">PikPak 网盘增强：集成 Aria2/Gopeed/ABDM/IDM 下载、下载直链加速、下载过滤、分享链接解析增强、文件/文件夹查重、批量重命名、资源清理、批量解压、PotPlayer 直达、M3U 导出、排序与搜索增强、TXT 磁链提取、数据迁移、目录树导出、以图搜图、视音频播放增强等。</p>
                    <div class="meta-line">
                        <span>今日安装 22</span>
                        <span>总安装 1,428</span>
                        <span>更新 2026-05-31</span>
                                                    <span>版本 3.1.0</span>
                                            </div>
                </article>
                                            <article class="script-row">
                    <h2>
                                                    <a class="script-title" href="/script.php?key=562508-%E5%A8%81%E8%BD%AF%E5%A4%B8%E5%85%8B%E5%8A%A9%E6%89%8B">威软夸克助手</a>
                                            </h2>
                    <p class="script-description">夸克网盘增强下载助手。支持批量下载、直链导出、aria2/IDM/cURL、下载历史、文件过滤、深色模式、快捷键操作。</p>
                    <div class="meta-line">
                        <span>今日安装 21</span>
                        <span>总安装 6,370</span>
                        <span>更新 2026-03-31 <span class="stale-update">太久没更新</span></span>
                                                    <span>版本 1.0.9</span>
                                            </div>
                </article>
                                            <article class="script-row">
                    <h2>
                                                    <a class="script-title" href="/script.php?key=402808-%E7%9F%A5%E4%B9%8E%E7%BE%8E%E5%8C%96">知乎美化</a>
                                            </h2>
                    <p class="script-description">1.【重要更新】增加夜间模式按钮     2.知乎题目栏增加举报、匿名、问题日志、快捷键四个按钮     3.知乎按钮图标在鼠标悬停时变色(题目按钮、回答下方按钮、评论按钮等)     4.回答的发布时间移至顶部     5.图片原图显示     6.文字和卡片链接从知乎跳转链接改为直链     7.隐藏侧边栏     8.GIF图自动播放【默认不开启】     9.问题增加创建时间和最后编辑时间     10.鼠标悬停在回答时显示浅蓝色聚焦框    11.引用角标高亮    12.首页信息流增加不感兴趣按钮  13.【重要更新】增加设置界面    14.显示信息流标签【默认不开启】</p>
                    <div class="meta-line">
                        <span>今日安装 21</span>
                        <span>总安装 3万</span>
                        <span>更新 2026-07-16</span>
                                                    <span>版本 2026.7.17</span>
                                            </div>
                </article>
                                            <article class="script-row">
                    <h2>
                                                    <a class="script-title" href="/script.php?key=415789-b%E7%AB%99%E8%A7%86%E9%A2%91%E4%B8%8B%E8%BD%BD%E8%A7%A3%E6%9E%90-2026-%E6%9C%80%E6%96%B0-bilibili-download">🔥🔥🔥B站视频下载解析 - 2026 最新 - BILIBILI Download</a>
                                            </h2>
                    <p class="script-description">快速解析B站视频，可直接下载MP4格式B站视频。</p>
                    <div class="meta-line">
                        <span>今日安装 21</span>
                        <span>总安装 9.7万</span>
                        <span>更新 2026-01-26 <span class="stale-update">太久没更新</span></span>
                                                    <span>版本 1.0.7</span>
                                            </div>
                </article>
                                            <article class="script-row">
                    <h2>
                                                    <a class="script-title" href="/script.php?key=419215-autopager">自动无缝翻页</a>
                                            </h2>
                    <p class="script-description">⭐无缝加载 下一页内容 至网页底部（类似瀑布流，无限滚动，无需手动点击下一页）⭐，支持各论坛、社交、游戏、漫画、小说、学术、搜索引擎(Google、Bing、Yahoo...) 等网站~</p>
                    <div class="meta-line">
                        <span>今日安装 21</span>
                        <span>总安装 57.8万</span>
                        <span>更新 2026-05-29</span>
                                                    <span>版本 6.6.75</span>
                                            </div>
                </article>
                                            <article class="script-row">
                    <h2>
                                                    <a class="script-title" href="/script.php?key=582721-multi-platform-video-downloader-save-youtube-tiktok-instagram-and-more">多平台视频下载神器｜YouTube、TikTok、抖音、小红书、Instagram 等平台一键保存</a>
                                            </h2>
                    <p class="script-description">为 YouTube、TikTok、抖音、小红书、Instagram、X/Twitter、Facebook、Threads 等平台添加下载入口，支持一键打开下载线路、线路选择和可用性测试。</p>
                    <div class="meta-line">
                        <span>今日安装 21</span>
                        <span>总安装 751</span>
                        <span>更新 2026-06-15</span>
                                                    <span>版本 0.5.1</span>
                                            </div>
                </article>
                                            <article class="script-row">
                    <h2>
                                                    <a class="script-title" href="/script.php?key=397848-comic-looms">漫画织机</a>
                                            </h2>
                    <p class="script-description">漫画阅读 + 下载器，注重体验和对站点的负载控制。支持你正在搜索的站点。</p>
                    <div class="meta-line">
                        <span>今日安装 20</span>
                        <span>总安装 5万</span>
                        <span>更新 2026-07-02</span>
                                                    <span>版本 4.15.0</span>
                                            </div>
                </article>
                                            <article class="script-row">
                    <h2>
                                                    <a class="script-title" href="/script.php?key=14146-%E7%BD%91%E9%A1%B5%E9%99%90%E5%88%B6%E8%A7%A3%E9%99%A4">网页限制解除</a>
                                            </h2>
                    <p class="script-description">通杀大部分网站，可以解除禁止复制、剪切、选择文本、右键菜单的限制。</p>
                    <div class="meta-line">
                        <span>今日安装 20</span>
                        <span>总安装 101.8万</span>
                        <span>更新 2022-01-09 <span class="stale-update">太久没更新</span></span>
                                                    <span>版本 1.3</span>
                                            </div>
                </article>
                                            <article class="script-row">
                    <h2>
                                                    <a class="script-title" href="/script.php?key=419894-image-downloader">图片下载器</a>
                                            </h2>
                    <p class="script-description">可以在绝大多数网站提取并批量下载图片。抓取能力大提升！现在可以抓取，H5游戏素材（4399），图库网站（千库网、包图网），漫画网站（腾讯漫画、b站漫画），文库网站（道客巴巴、豆丁），以及其他右键失效或者图片不能另存的网站，用脚本均可以提取并下载。额外功能：zip下载/自动大图。详细见脚本描述(目前适合chrome/firefox+tampermonkey，其他组合多少有问题）</p>
                    <div class="meta-line">
                        <span>今日安装 20</span>
                        <span>总安装 20.5万</span>
                        <span>更新 2024-01-18 <span class="stale-update">太久没更新</span></span>
                                                    <span>版本 2.90</span>
                                            </div>
                </article>
                                            <article class="script-row">
                    <h2>
                                                    <a class="script-title" href="/script.php?key=484953-%E7%99%BE%E5%BA%A6%E7%BD%91%E7%9B%98%E4%B8%8B%E8%BD%BD%E5%8A%A9%E6%89%8B">百度网盘下载助手</a>
                                            </h2>
                    <p class="script-description">可以获取网盘文件真实下载地址。现已支持百度网盘、阿里网盘、天翼网、盘迅雷网盘、夸克网盘、移动网盘（139网盘）六大网盘，基于【网盘直链下载助手】修改自1.0.8.2版本,自用,去推广,修原有BUG,修改界面,甚至比原版还好用！</p>
                    <div class="meta-line">
                        <span>今日安装 20</span>
                        <span>总安装 11.4万</span>
                        <span>更新 2024-02-19 <span class="stale-update">太久没更新</span></span>
                                                    <span>版本 1.2.2</span>
                                            </div>
                </article>
                                            <article class="script-row">
                    <h2>
                                                    <a class="script-title" href="/script.php?key=529376-linkswift00">LinkSwift00</a>
                                            </h2>
                    <p class="script-description">(｡&gt;ᴗ•)✧《也许同类型中最好用？》系列 - 一个基于 JavaScript 的网盘文件下载地址获取工具✨，基于【网盘直链下载助手】修改 | 支持 百度网盘 / 阿里云盘 / 中国移动云盘 / 天翼云盘 / 迅雷云盘 / 夸克网盘 / UC网盘 / 123云盘 八大网盘 | 开源・自用・去广 | 改界面・添功能・修Bug | 既超越原版，亦是同类中最好用版本！👋</p>
                    <div class="meta-line">
                        <span>今日安装 20</span>
                        <span>总安装 9,048</span>
                        <span>更新 2026-01-15 <span class="stale-update">太久没更新</span></span>
                                                    <span>版本 1.1.2.1</span>
                                            </div>
                </article>
                                            <article class="script-row">
                    <h2>
                                                    <a class="script-title" href="/script.php?key=529453-twitter-x-media-downloader">Twitter 媒体下载 (2025.12.02 修复)</a>
                                            </h2>
                    <p class="script-description">一键下载视频/图片,支持批量下载时自动打包为一个ZIP文件下载.支持新版API接口</p>
                    <div class="meta-line">
                        <span>今日安装 20</span>
                        <span>总安装 1万</span>
                        <span>更新 2026-04-02 <span class="stale-update">太久没更新</span></span>
                                                    <span>版本 2026.4.2.2</span>
                                            </div>
                </article>
                                            <article class="script-row">
                    <h2>
                                                    <a class="script-title" href="/script.php?key=438657-%E5%85%A8%E7%BD%91vip%E8%A7%86%E9%A2%91%E5%85%8D%E8%B4%B9%E7%A0%B4%E8%A7%A3-%E4%B8%93%E6%B3%A8%E4%B8%80%E4%B8%AA%E8%84%9A%E6%9C%AC%E5%8F%AA%E5%81%9A%E4%B8%80%E4%BB%B6%E4%BA%8B%E4%BB%B6">全网VIP视频免费破解【专注一个脚本只做一件事件】</a>
                                            </h2>
                    <p class="script-description">全网VIP视频免费破解【专注一个脚本只做一件事件】。支持：腾讯、爱奇艺、优酷、芒果、pptv、乐视等其它网站；</p>
                    <div class="meta-line">
                        <span>今日安装 19</span>
                        <span>总安装 155.9万</span>
                        <span>更新 2023-12-01 <span class="stale-update">太久没更新</span></span>
                                                    <span>版本 1.7.0</span>
                                            </div>
                </article>
                                            <article class="script-row">
                    <h2>
                                                    <a class="script-title" href="/script.php?key=485020-dvr-chan-force-enable-youtube-dvr-rewind-formerly-ytbetter">DVR-chan – 强制启用 YouTube DVR/Rewind（原 YTBetter）</a>
                                            </h2>
                    <p class="script-description">强制在任何 YouTube 直播中启用 DVR 回看，即使主播已将其关闭。回看窗口延长至 7 天。</p>
                    <div class="meta-line">
                        <span>今日安装 19</span>
                        <span>总安装 5,714</span>
                        <span>更新 2026-06-08</span>
                                                    <span>版本 4.1</span>
                                            </div>
                </article>
                                            <article class="script-row">
                    <h2>
                                                    <a class="script-title" href="/script.php?key=487867-auto-duolingo">Auto-Duolingo</a>
                                            </h2>
                    <p class="script-description">[LITE] 自动完成课程，自动刷XP，破解连续天数、宝石等！黑掉Duolingo就是这么简单！</p>
                    <div class="meta-line">
                        <span>今日安装 19</span>
                        <span>总安装 3.2万</span>
                        <span>更新 2026-07-11</span>
                                                    <span>版本 1.1.1</span>
                                            </div>
                </article>
                                            <article class="script-row">
                    <h2>
                                                    <a class="script-title" href="/script.php?key=508784-youtube-hd-plus">YouTube HD Plus</a>
                                            </h2>
                    <p class="script-description">自动选择您偏好的视频画质，并在可用时启用 Premium 播放。 (支持 YouTube 桌面版、音乐和移动端)</p>
                    <div class="meta-line">
                        <span>今日安装 19</span>
                        <span>总安装 7,185</span>
                        <span>更新 2026-07-07</span>
                                                    <span>版本 2.8.2</span>
                                            </div>
                </article>
                                            <article class="script-row">
                    <h2>
                                                    <a class="script-title" href="/script.php?key=531394-bilibili-b-%E7%AB%99%E6%B5%8F%E8%A7%88%E5%8A%A9%E6%89%8B">Bilibili B 站浏览助手</a>
                                            </h2>
                    <p class="script-description">增强功能：查看封面、下载字幕、下载评论、下载视频(支持 4K/8K)、AI 总结字幕、素材酷平台视频下载、用户空间批量下载、个人收藏批量下载。</p>
                    <div class="meta-line">
                        <span>今日安装 19</span>
                        <span>总安装 407</span>
                        <span>更新 2026-07-16</span>
                                                    <span>版本 3.5</span>
                                            </div>
                </article>
                                            <article class="script-row">
                    <h2>
                                                    <a class="script-title" href="/script.php?key=573660-universal-media-pro-toolkit-video-download-url-extract-play">全能媒体工作台 | 视频下载、URL地址提取、点击一键播放、万能网页视频播放器</a>
                                            </h2>
                    <p class="script-description">提取视频直链、一键下载媒体文件，并在极简悬浮窗中实现一键播放。</p>
                    <div class="meta-line">
                        <span>今日安装 19</span>
                        <span>总安装 2,033</span>
                        <span>更新 2026-04-14 <span class="stale-update">太久没更新</span></span>
                                                    <span>版本 1.0.1</span>
                                            </div>
                </article>
                                            <article class="script-row">
                    <h2>
                                                    <a class="script-title" href="/script.php?key=575941-youtube-ads-bypass">YouTube Ads-Bypass (跳过并隐藏所有广告)</a>
                                            </h2>
                    <p class="script-description">轻量且高效的脚本，用于跳过视频广告并隐藏干扰性 UI 元素（横幅、覆盖层和促销活动）。</p>
                    <div class="meta-line">
                        <span>今日安装 19</span>
                        <span>总安装 7,093</span>
                        <span>更新 2026-06-12</span>
                                                    <span>版本 1.28.3</span>
                                            </div>
                </article>
                                            <article class="script-row">
                    <h2>
                                                    <a class="script-title" href="/script.php?key=577798-x-vault-x-%E7%8F%8D%E8%97%8F%E9%A6%86-%E6%8E%A8%E7%89%B9-x-%E7%BB%88%E6%9E%81%E5%AA%92%E4%BD%93%E4%B8%8B%E8%BD%BD-4k%E5%8E%9F%E5%9B%BE-%E8%A7%86%E9%A2%91-zip%E6%89%93%E5%8C%85">X-Vault (X-珍藏馆) | 推特/X 终极媒体下载 (4K原图/视频/ZIP打包)</a>
                                            </h2>
                    <p class="script-description">X-Vault: 推特/X 终极媒体下载神器。支持 4K 原图/最高画质视频提取、智能分类归档、批量 ZIP 打包、点赞自动下载及博主历史媒体全量抓取。</p>
                    <div class="meta-line">
                        <span>今日安装 19</span>
                        <span>总安装 813</span>
                        <span>更新 2026-07-13</span>
                                                    <span>版本 1.4.7</span>
                                            </div>
                </article>
                                            <article class="script-row">
                    <h2>
                                                    <a class="script-title" href="/script.php?key=25068-downloadallcontent">怠惰小说下载器</a>
                                            </h2>
                    <p class="script-description">通用网站内容爬虫抓取工具，可批量抓取任意站点的小说、论坛内容等并保存为TXT文档</p>
                    <div class="meta-line">
                        <span>今日安装 18</span>
                        <span>总安装 17.6万</span>
                        <span>更新 2025-12-01 <span class="stale-update">太久没更新</span></span>
                                                    <span>版本 2.8.3.19</span>
                                            </div>
                </article>
                                            <article class="script-row">
                    <h2>
                                                    <a class="script-title" href="/script.php?key=474193-steam%E6%98%BE%E7%A4%BA%E9%9A%90%E8%97%8F%E7%9A%84%E5%81%8F%E5%A5%BD%E8%AE%BE%E7%BD%AE">Steam显示隐藏的偏好设置</a>
                                            </h2>
                    <p class="script-description">将Steam偏好设置里隐藏的设置完整的显示出来，包括选项的标题和描述。可解决例如Wallpaper Engine:壁纸引擎 锁国区等问题</p>
                    <div class="meta-line">
                        <span>今日安装 18</span>
                        <span>总安装 9,471</span>
                        <span>更新 2023-09-11 <span class="stale-update">太久没更新</span></span>
                                                    <span>版本 0.4</span>
                                            </div>
                </article>
                                            <article class="script-row">
                    <h2>
                                                    <a class="script-title" href="/script.php?key=522662-youtube-video-downloader-hd-2k-4k-quality-video-audio-cover">YouTube油管视频下载🤩&amp;去广告多合一｜HD/2K/4K｜视频&amp;音频&amp;获取封面 🔥📥</a>
                                            </h2>
                    <p class="script-description">YouTube视频下载神器，支持1080P/2K高清视频下载，封面下载，支持视频/音频分离下载，合并下载</p>
                    <div class="meta-line">
                        <span>今日安装 18</span>
                        <span>总安装 1.1万</span>
                        <span>更新 2026-02-28 <span class="stale-update">太久没更新</span></span>
                                                    <span>版本 0.4</span>
                                            </div>
                </article>
                                            <article class="script-row">
                    <h2>
                                                    <a class="script-title" href="/script.php?key=531756-smart-auto-redirect-scroll">旁路 全部 短链接</a>
                                            </h2>
                    <p class="script-description">Bypass All Shortlinks Sites Automatically Skips Annoying Link Shorteners , Skip AdFly and No Annoying Ads, Directly to Your Destination, and now Support Auto Downloading Your Files</p>
                    <div class="meta-line">
                        <span>今日安装 18</span>
                        <span>总安装 3,004</span>
                        <span>更新 2025-04-13 <span class="stale-update">太久没更新</span></span>
                                                    <span>版本 1.3</span>
                                            </div>
                </article>
                                            <article class="script-row">
                    <h2>
                                                    <a class="script-title" href="/script.php?key=536712-youtube-ads-bypasser">自动跳过 YouTube 广告 by DarkShadow44</a>
                                            </h2>
                    <p class="script-description">立即自动跳过 YouTube 广告。不会被 YouTube 广告拦截器警告检测到。由 DarkShadow44 增强。</p>
                    <div class="meta-line">
                        <span>今日安装 18</span>
                        <span>总安装 4,448</span>
                        <span>更新 2025-05-21 <span class="stale-update">太久没更新</span></span>
                                                    <span>版本 7.2.3</span>
                                            </div>
                </article>
                                            <article class="script-row">
                    <h2>
                                                    <a class="script-title" href="/script.php?key=552210-linux-do-%E5%B0%8F%E5%8A%A9%E6%89%8B-%E5%A2%9E%E5%BC%BA%E7%89%88">linux.do 小助手（增强版）</a>
                                            </h2>
                    <p class="script-description">自动浏览、点赞、只看楼主、楼层号、保存帖子到本地、清爽模式、黑白灰模式、用户信息展示（批量展示）、查看用户话题、Credit积分悬浮窗。支持拖动和最小化控制面板。支持 linux.do 和 idcflare.com</p>
                    <div class="meta-line">
                        <span>今日安装 18</span>
                        <span>总安装 3,507</span>
                        <span>更新 2026-04-29 <span class="stale-update">太久没更新</span></span>
                                                    <span>版本 1.9.2</span>
                                            </div>
                </article>
                                            <article class="script-row">
                    <h2>
                                                    <a class="script-title" href="/script.php?key=573418-telegram-media-downloader-global-edition">Telegram 媒体下载器 全球版 (视频下载、保存原图、压缩、转换 PNG)</a>
                                            </h2>
                    <p class="script-description">绕过限制一键下载视频和图片，支持视频保存、保存原图、图片压缩及转换为 PNG。全球版。</p>
                    <div class="meta-line">
                        <span>今日安装 18</span>
                        <span>总安装 3,172</span>
                        <span>更新 2026-04-11 <span class="stale-update">太久没更新</span></span>
                                                    <span>版本 1.0.0</span>
                                            </div>
                </article>
                                            <article class="script-row">
                    <h2>
                                                    <a class="script-title" href="/script.php?key=586323-miss-player-%E5%BD%B1%E9%99%A2%E6%A8%A1%E5%BC%8F-%E5%8D%95%E6%89%8B%E6%92%AD%E6%94%BE%E5%99%A8">Miss Player | 影院模式 (单手播放器)</a>
                                            </h2>
                    <p class="script-description">MissAV去广告|单手模式|MissAV自动展开详情|MissAV自动高画质|MissAV重定向支持|MissAV自动登录|定制播放器|多语言支持 支持 jable po*nhub 等通用</p>
                    <div class="meta-line">
                        <span>今日安装 18</span>
                        <span>总安装 76</span>
                        <span>更新 2026-07-15</span>
                                                    <span>版本 5.1.14</span>
                                            </div>
                </article>
                                            <article class="script-row">
                    <h2>
                                                    <a class="script-title" href="/script.php?key=457151-ocs-%E7%BD%91%E8%AF%BE%E5%8A%A9%E6%89%8B">OCS 网课助手</a>
                                            </h2>
                    <p class="script-description">OCS(online-course-script) 网课助手，官网 https://docs.ocsjs.com ，专注于帮助大学生从网课中释放出来 让自己的时间把握在自己的手中，拥有人性化的操作页面，流畅的步骤提示，支持  【超星学习通】 【知到智慧树】 【职教云】 【智慧职教】 【中国大学MOOC】 【雨课堂】 等网课的学习，作业。具体的功能请查看脚本悬浮窗中的教程页面。</p>
                    <div class="meta-line">
                        <span>今日安装 17</span>
                        <span>总安装 245.3万</span>
                        <span>更新 2026-07-01</span>
                                                    <span>版本 4.15.3</span>
                                            </div>
                </article>
                                            <article class="script-row">
                    <h2>
                                                    <a class="script-title" href="/script.php?key=463832-%E7%99%BE%E5%BA%A6%E7%BD%91%E7%9B%98%E4%B8%8D%E9%99%90%E9%80%9F%E4%B8%8B%E8%BD%BD-kubedown">百度网盘不限速下载-KubeDown</a>
                                            </h2>
                    <p class="script-description">百度网盘不限速下载-KubeDown-Script</p>
                    <div class="meta-line">
                        <span>今日安装 17</span>
                        <span>总安装 60.2万</span>
                        <span>更新 2023-10-20 <span class="stale-update">太久没更新</span></span>
                                                    <span>版本 2.4</span>
                                            </div>
                </article>
                                            <article class="script-row">
                    <h2>
                                                    <a class="script-title" href="/script.php?key=494643-%E6%8A%96%E9%9F%B3%E4%BC%98%E5%8C%96">抖音优化</a>
                                            </h2>
                    <p class="script-description">视频过滤，包括广告、直播或自定义规则，屏蔽登录弹窗、自定义视频清晰度、禁止自动播放、自动进入全屏、双击进入全屏、屏蔽弹幕和礼物特效、手机模式、自定义视频和评论区背景色等</p>
                    <div class="meta-line">
                        <span>今日安装 17</span>
                        <span>总安装 2.9万</span>
                        <span>更新 2026-07-10</span>
                                                    <span>版本 2026.7.10</span>
                                            </div>
                </article>
                    </div>

                <nav class="pagination is-small mt-5" role="navigation" aria-label="pagination">
                            <a class="pagination-previous" disabled>上一页</a>
                        <a class="pagination-next" href="/index.php?page=2">下一页</a>
        </nav>
    </div>

    <aside class="column is-3">
        <div class="side-panel">
            <h2 class="title is-6">排序</h2>
            <div class="sort-list">
                                                        <a class="is-active" href="/index.php">日安装量</a>
                                                        <a class="" href="/index.php?sort=total_installs">总安装量</a>
                                                        <a class="" href="/index.php?sort=ratings">得分</a>
                                                        <a class="" href="/index.php?sort=created">创建日期</a>
                                                        <a class="" href="/index.php?sort=updated">更新日期</a>
                                                        <a class="" href="/index.php?sort=name">脚本名称</a>
                            </div>
                    </div>
    </aside>
</div>

    </div>
</main>
<button class="back-to-top" type="button" aria-label="Back to top" title="Back to top" style="align-items:center;background:#155e2b;border:0;border-radius:999px;bottom:11rem;box-shadow:0 8px 22px rgba(21,94,43,.22);color:#fff;cursor:pointer;display:flex;font-size:1.35rem;font-weight:700;height:3rem;justify-content:center;line-height:1;position:fixed;right:20rem;text-align:center;width:3rem;z-index:9999;">&uarr;</button>
<script src="https://cdn.bootcdn.net/ajax/libs/highlight.js/11.9.0/highlight.min.js"></script>
<script defer src="https://greasyfork.cn/eval.js"></script>
<script>
(function () {
    if (window.hljs) {
        hljs.highlightAll();
    }

    var button = document.querySelector('.back-to-top');
    if (!button) {
        button = document.createElement('button');
        button.className = 'back-to-top';
        button.type = 'button';
        button.setAttribute('aria-label', 'Back to top');
        button.title = 'Back to top';
        button.innerHTML = '&uarr;';
        document.body.appendChild(button);
    }

    // Object.assign(button.style, {
    //     alignItems: 'center',
    //     background: '#155e2b',
    //     border: '0',
    //     borderRadius: '999px',
    //     bottom: '11rem',
    //     boxShadow: '0 8px 22px rgba(21,94,43,.22)',
    //     color: '#fff',
    //     cursor: 'pointer',
    //     display: 'flex',
    //     fontSize: '1.35rem',
    //     fontWeight: '700',
    //     height: '3rem',
    //     justifyContent: 'center',
    //     lineHeight: '1',
    //     position: 'fixed',
    //     right: '20rem',
    //     textAlign: 'center',
    //     width: '3rem',
    //     zIndex: '9999'
    // });

    button.addEventListener('click', function () {
        window.scrollTo({ top: 0, behavior: 'smooth' });
    });
})();
</script>
</body>
</html>
    