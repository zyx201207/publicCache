// ==UserScript==
// @name         Vjudge Cookie Filler
// @namespace    http://tampermonkey.net/
// @version      1.0.1
// @description  自动填充Cookie
// @author       You
// @match        https://*/*
// @icon         data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==
// @grant        GM_xmlhttpRequest
// ==/UserScript==

GM_xmlhttpRequest({
  method: "GET",
  url: "https://target-website.com/api/data",
  headers: { "Content-Type": "application/json" },
  onload: function(response) {
    // 从响应头提取Set-Cookie
    const cookies = response.responseHeaders.match(/Set-Cookie: ([^;]+)/i);
    console.log("跨域Cookie:", cookies);
  }
});
