// ==UserScript==
// @name         Vjudge题目搜索
// @version      1.0.2
// @description  在Vjudge题面中添加搜索原题的链接
// @author       zyx2012
// @match        https://vjudge.net/*
// @grant        none
// @license      MIT
// ==/UserScript==

function main(){
	function select(){
		document.querySelectorAll("#problem-title").forEach((element) => {
			if (element.textContent == element.innerHTML){
				let str = element.textContent;
				str = str.substr(4,str.length);

				if (str[0] == "("||str[0] == "（"){
					let top = 0;

					for (let i = 0;i < str.length;i++){
						if (str[i] == '('||str[i] == "）")
							top++;
						if (str[i] == ')'||str[i] == "）")
							top--;

						if (!top){
							str = str.substr(i + 1,str.length);
							break;
						}
					}
				}

				let str2 = ``;

				for (let i = 0;i < str.length;i++)
					str2 += (str[i] == ' '?'+':str[i]);

				function gotoClist(){
					window.open(`https://clist.by/problems/?search=${str2}`);
				};

				function gotoLuogu(){
					window.open(`https://www.luogu.com.cn/problem/list?type=all&keyword=${str2}&page=1`);
				};

				function getSmall(elem, v){
					if (!v) return elem;
					let ret = document.createElement("small");
					ret.append(getSmall(elem,v - 1));
					return ret;
				};

                let elem = document.createElement("button");
                elem.className = "btn btn-secondary";
                elem.style.color = "#C0C000";
                elem.innerHTML = `在CLIST上搜索此题`;
				elem.addEventListener("click",gotoClist);
				element.append(getSmall(elem,4));
                elem = document.createElement("button");
                elem.className = "btn btn-secondary";
                elem.style.color = "#00C0C0";
				elem.innerHTML = `在洛谷上搜索此题`;
				elem.addEventListener("click",gotoLuogu);
				element.append(getSmall(elem,4));
            }
		});
	};
	select();
	for (let i = 0;i < 26;i++){
		let str = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"[i];
		document.querySelectorAll(`a.nav-link[num="${str}"][href="#problem/${str}"]`).forEach((element) => {
		    function listener(){
		        window.location.replace(`#problem/${str}`);
		        setTimeout(select,200);
		    };
		    element.addEventListener("click", listener);
		});
	}
}

setTimeout(main,200);