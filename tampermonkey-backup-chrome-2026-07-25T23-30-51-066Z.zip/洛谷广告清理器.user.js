// ==UserScript==
// @name         洛谷广告清理器
// @namespace    http://tampermonkey.net/
// @version      1.0.1
// @description  清除洛谷广告
// @author       zyx2012
// @match        *://www.luogu.com.cn/*
// @icon         https://cdn.luogu.com.cn/upload/usericon/1934210.png
// @license      MIT
// @grant        none
// ==/UserScript==

function erase1(){
    document.querySelectorAll(".lform-size-small.close").forEach((elem) => {
        elem.parentNode.remove();
    });
}
erase1();
function erase2(){
    document.querySelectorAll("#app-old > div.lg-index-content.am-center > div:nth-child(1) > div > div > div > div.am-u-md-8").forEach((elem) => {
        elem.remove();
    });
    document.querySelectorAll("#app-old > div.lg-index-content.am-center > div:nth-child(1) > div > div > div > div").forEach((elem) => {
        elem.parentNode.style.display = "flex";
        elem.style = "margin-left: auto;margin-right: auto;";
    });
}
const observer = new MutationObserver((mutations, obs) => {
    obs.disconnect();
    erase1();
    erase2();
    obs.observe(document.body, {
        childList: true,
        subtree: true
    });
});
observer.observe(document.body, {
    childList: true,
    subtree: true
});
