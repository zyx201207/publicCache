// ==UserScript==
// @name         zyxOT犇犇修复器
// @namespace    http://tampermonkey.net/
// @version      1.0.1
// @description  修复犇犇
// @author       zyx2012
// @match        https://zyxot.xo.je/benben*
// @grant        none
// @license      MIT
// ==/UserScript==

function main(){
    const area = document.createElement("textarea");
    area.setAttribute("id","input-comment_editor");
    area.setAttribute("class","form-control");
    document.querySelector("#comment-markdown-input-container").append(area);
}

main();