// ==UserScript==
// @name         GenGen-CF-RMJ
// @namespace    http://tampermonkey.net/
// @version      3.2.1
// @match        https://www.luogu.com.cn/problem/CF*
// @connect      codeforces.com
// @grant        GM_xmlhttpRequest
// @require      https://cdn.jsdelivr.net/npm/sweetalert2@11
// @license      MIT
// @description  GenGen RMJ （Codeforces 提交，不支持 Cloudflare 盾）
// ==/UserScript==


(async function () {
  'use strict';
  if (document.readyState !== 'complete')
    await new Promise(r => addEventListener('load', r, { once: true }));
  if (!window.location.href.startsWith('https://www.luogu.com.cn/problem/CF')) {
    return;
  }

  const steps = [
    "正在获取代码...",
    "正在连接 Codeforces 服务器...",
    "正在获取安全令牌...",
    "正在提交代码到 Codeforces...",
    "正在验证提交..."
  ];

  let currentSwal = null;

  function initSwalStyles() {
    const style = document.createElement('style');
    style.textContent = `
      /* 隐藏标题 */
      .swal2-title {
        display: none !important;
      }
      .swal2-loading-popup .swal2-html-container {
        padding: 24px !important;
      }
      .swal2-html-container{
        font-size: 22px !important;
      }
      .swal2-custom-content {

        display: flex;
        flex-direction: column;
        align-items: center;
        text-align: center;
        gap: 16px;
      }

      .swal2-loader {
        width: 48px !important;
        height: 48px !important;
        border-width: 5px !important;
        margin: 0 !important;
      }

      #swal2-loading-message {
        font-size: 18px !important;
        color: #666 !important;
        margin: 0 !important;
      }
      .swal2-cancel, .swal2-confirm {
        font-size: 18px !important;
        padding: 10px 20px !important;
      }
    `;
    document.head.appendChild(style);
  }

  function showLoading(message) {
    currentSwal = Swal.fire({
      html: `
        <div class="swal2-custom-content">
          <div class="swal2-loader"></div>
          <div id="swal2-loading-message">${message}</div>
        </div>
      `,
      customClass: {
        popup: 'swal2-loading-popup'
      },
      allowOutsideClick: false,
      allowEscapeKey: false,
      showConfirmButton: false,
      showCancelButton: false,
      didOpen: () => {
        const loader = Swal.getLoader();
        if (loader) loader.style.display = 'block';
      },
      willClose: () => {
        resetLuoguButton();
      }
    });
  }

  // 更新说明文字
  function updateLoadingMessage(message) {
    const el = document.getElementById('swal2-loading-message');
    if (el) el.textContent = message;
  }

  // ===== 以下函数保持不变 =====

  function showError(message, detail = null) {
    if (currentSwal) currentSwal.close();
    let errorMessage = message;
    if (detail) {
      errorMessage = `${message}<br><small style="color: #888; font-size: 14px;">${detail}</small>`;
    }
    Swal.fire({
      icon: 'error',
      title: '提交失败',
      html: errorMessage,
      confirmButtonText: '确定',
      willClose: () => resetLuoguButton()
    });
  }

  function showSuccess() {
    if (currentSwal) currentSwal.close();
    Swal.fire({
      icon: 'success',
      title: '提交成功',
      text: '正在跳转到提交记录...',
      showConfirmButton: false,
      timer: 1500,
      timerProgressBar: true,
      willClose: () => {
        const urlMatch = location.pathname.match(/CF(\d+)([A-Z]\d?)/i);
        if (urlMatch) {
          const contestId = urlMatch[1];
          const index = urlMatch[2];
          window.location.href = `https://www.luogu.com.cn/record/list?rmj=1&pid=CF${contestId}${index}`;
        }
      }
    });
  }

  function resetLuoguButton() {
    const btn = document.querySelector("#app > div.main-container.lside-nav > div > main > div > div > div.main > div > div.body > button");
    if (btn) {
      btn.disabled = false;
      btn.style.pointerEvents = "auto";
      btn.style.opacity = "1";
      const loadingSpinner = btn.querySelector('.loading-spinner, .spinner');
      if (loadingSpinner) loadingSpinner.remove();
    }
  }

  function detectLuoguButton() {
    const btn = document.querySelector("#app > div.main-container.lside-nav > div > main > div > div > div.main > div > div.body > button");
    if (btn && !btn.dataset.genCfBound) {
      btn.dataset.genCfBound = "1";
      const newBtn = btn.cloneNode(true);
      newBtn.addEventListener("click", (e) => {
        e.preventDefault();
        e.stopPropagation();
        btn.disabled = true;
        btn.style.pointerEvents = "none";
        btn.style.opacity = "0.7";
        startSubmit();
      });
      btn.replaceWith(newBtn);
    } else if (!btn) {
      setTimeout(detectLuoguButton, 500);
    }
  }

  async function startSubmit() {
    const urlMatch = location.pathname.match(/CF(\d+)([A-Z]\d?)/i);
    if (!urlMatch) {
      showError("无法解析 Codeforces 题目ID");
      return;
    }

    const contestId = urlMatch[1];
    const index = urlMatch[2];

    try {
      showLoading(steps[0]);
      const code = await getFullCodeSafe();

      updateLoadingMessage(steps[1]);
      const submitPage = await fetchCfSubmitPage(contestId, index);
      if (!submitPage.includes('Logout')) {
        updateLoadingMessage("未登录 Codeforces，正在跳转...");
        setTimeout(() => {
          window.location.href = `https://codeforces.com/enter?back=${encodeURIComponent(window.location.href)}`;
        }, 1000);
        return;
      }

      updateLoadingMessage(steps[2]);
      const token = extractCsrfToken(submitPage);
      if (!token) {
        showError("获取安全令牌失败", "请刷新页面重试");
        return;
      }

      updateLoadingMessage(steps[3]);
      await submitCode(contestId, index, code, token);

      updateLoadingMessage(steps[4]);
      showSuccess();

    } catch (err) {
      console.error("[Gen-CF-RMJ] 提交错误:", err);
      if (err.message.includes('You have submitted exactly the same code before') || err.message.includes('请不要提交相同代码')) {
        showError("您已经提交过完全相同的代码");
      } else if (err.message.includes('network') || err.message.includes('Network')) {
        showError("网络连接失败");
      } else {
        window.scrollTo(0, 0);
        Swal.close();
        setTimeout(() => {
          RMJ_CF_SUBMIT();
        }, 50);

      }
    }
  }

  async function getFullCodeSafe() {
      const c = document.querySelector('.cm-content');
      if (!c) return '';

      c.focus();
      await new Promise(r => requestAnimationFrame(() => requestAnimationFrame(r)));

      for (let i = 0; i < 3; i++) {
        c.dispatchEvent(new KeyboardEvent('keydown', { key: 'a', code: 'KeyA', ctrlKey: true, bubbles: true }));
        await new Promise(r => setTimeout(r, 50));

        const d = { data: {}, setData(k, v) { this.data[k] = v; }, clearData() {} };
        const e = new Event('copy', { bubbles: true });
        Object.defineProperty(e, 'clipboardData', { value: d });
        c.dispatchEvent(e);

        const code = d.data['text/plain'] || '';
        if (code.trim()) {
          c.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true }));
          return code;
        }
        await new Promise(r => setTimeout(r, 100 * (i + 1)));
      }

      c.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true }));
      return '';
  }

  function fetchCfSubmitPage(contestId, index) {
    return new Promise((resolve, reject) => {
      GM_xmlhttpRequest({
        method: "GET",
        url: "https://codeforces.com/problemset/submit",
        onload: function (res) {
          if (res.status === 200) resolve(res.responseText);
          else reject(new Error(`HTTP ${res.status}: 无法访问 Codeforces 提交页面`));
        },
        onerror: () => reject(new Error("网络连接失败"))
      });
    });
  }

  function extractCsrfToken(html) {
    const match = html.match(/<meta name="X-Csrf-Token" content="([^"]*)"/);
    return match ? match[1] : null;
  }

  function submitCode(contestId, index, code, token) {
    return new Promise((resolve, reject) => {
      const formData = new URLSearchParams();
      formData.append("csrf_token", token);
      formData.append("action", "submitSolutionFormSubmitted");
      formData.append("contestId", contestId);
      formData.append("submittedProblemIndex", index);
      formData.append("programTypeId", "91");
      formData.append("source", code);
      formData.append("tabSize", "4");
      formData.append("_tta", "377");

      GM_xmlhttpRequest({
        method: "POST",
        url: "https://codeforces.com/problemset/submit",
        data: formData.toString(),
        headers: {
          "Content-Type": "application/x-www-form-urlencoded",
          "Origin": "https://codeforces.com",
          "Referer": "https://codeforces.com/problemset/submit"
        },
        onload: function (res) {
          if (res.status === 200) {
            if (res.finalUrl?.includes("/problemset/status") || res.responseText.includes("submitted successfully")) {
              resolve();
            } else if (res.responseText.includes("You have submitted exactly the same code before")) {
              reject(new Error("请不要提交相同代码"));
            } else {
              reject(new Error("被 Codeforces 服务器拒绝"));
            }
          } else {
            reject(new Error(`HTTP ${res.status}: 提交请求失败`));
          }
        },
        onerror: () => reject(new Error("网络请求失败"))
      });
    });
  }

  initSwalStyles();
  detectLuoguButton();
})();