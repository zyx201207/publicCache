// ==UserScript==
// @name         CSDN登录复制消灭器
// @namespace    http://tampermonkey.net/
// @version      1.0.2
// @description  去你妈了个登录复制！老子直接把登录弹窗都给你灭了！
// @author       zyx2012
// @match        *://blog.csdn.net/*
// @icon         https://img.atcoder.jp/icons/055ca0bedbd012c31bf56bc8f1774d29.jpg
// @grant        none
// @license      MIT
// ==/UserScript==

function remove(){//垃圾弹窗拦截、
    let b = 0;
    function kill(selector){
        if (b) return ;
        document.querySelectorAll(selector).forEach((elem) => {
            console.log(`拦截垃圾弹窗`);
            elem.remove();
        });
    }
    function modifybase(elem){
        elem.setAttribute(`data-title`, `点击复制`);
        elem.classList.remove('signin');
        let oth = elem.cloneNode(true);
        oth.click = null;
        elem.parentNode.replaceChild(oth,elem);
        elem = oth;
        elem.addEventListener('click', () => {
            elem.setAttribute('data-title', '^_^');
//            alert(elem.parentNode.previousElementSibling.innerText);
            navigator.clipboard.writeText(elem.parentNode.previousElementSibling.innerText);
            elem.setAttribute('data-title', '复制成功');
            setTimeout(() => {elem.setAttribute(`data-title`, `点击复制`);},5000);
        });
    }
    function modify(selector){
        document.querySelectorAll(selector).forEach((elem) => {modifybase(elem);});
    }
    let banned = ["#csdn-toolbar-profile-nologin",".passport-login-container",".passport-login-tip-container"];//封杀名单
    let modifies = [".hljs-button"];//修正名单
    const observer = new MutationObserver((mutations, obs) => {
        document.oncopy=null;
        window.oncopy=null;
        obs.disconnect();
        banned.forEach(kill);
        obs.observe(document.body, {
            childList: true,
            subtree: true,
            attributes: true,
            characterData: true,
            attributeOldValue: false,
            characterDataOldValue: false
        });
    });
    setTimeout(() => {modifies.forEach(modify);},0);
    setTimeout(() => {modifies.forEach(modify);},200);
    setTimeout(() => {modifies.forEach(modify);},400);
    setTimeout(() => {modifies.forEach(modify);},600);

    observer.observe(document.body, {
        childList: true,
        subtree: true,
        attributes: true,
        characterData: true,
        attributeOldValue: false,
        characterDataOldValue: false
    });
    banned.forEach(kill);

    setTimeout(() => {
        setTimeout(() => {
            document.querySelector('#article_content').style.height='auto';document.querySelector('.hide-article-box').style.display='none';
        },0);
        document.querySelectorAll(".toolbar-btn.toolbar-btn-login.toolbar-btn-login-new.csdn-toolbar-fl").forEach((elem) => {
            if (elem.textContent.trim() == "登录"){
                function go(){
                    b = 1;
                    function back(){
                        b = 0;
                    }
                    setTimeout(back,6000);
                    setTimeout(() => {document.querySelectorAll("#passportbox > img").forEach((elem) => {elem.addEventListener("click",back);});},200);
                }
                elem.addEventListener("click",go);
            }
        });
    },200);
    document.addEventListener("copy", (elem) => {navigator.clipboard.writeText(window.getSelection().toString());},true);
    document.addEventListener("keydown", (elem) => {if (elem.ctrlKey && elem.keyCode == 67) navigator.clipboard.writeText(window.getSelection().toString());},true);
}

remove();
